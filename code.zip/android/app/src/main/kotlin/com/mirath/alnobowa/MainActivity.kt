package com.mirath.alnobowa

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
