import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'main.dart';

// ════════════════════════════════════════════════════════════
//  نظام التصاميم
// ════════════════════════════════════════════════════════════

class DesignSpec {
  final int id;
  final String name;
  final String desc;
  final IconData icon;
  final Color seed;
  final Color primary;
  final Color highlight;
  final Color bg;
  final Color card;
  final Color ink;
  final Color textAccent;
  final bool alwaysDark;
  const DesignSpec({
    required this.id,
    required this.name,
    required this.desc,
    required this.icon,
    required this.seed,
    required this.primary,
    required this.highlight,
    required this.bg,
    required this.card,
    required this.ink,
    required this.textAccent,
    this.alwaysDark = false,
  });
}

const designSpecs = <DesignSpec>[
  DesignSpec(
    id: 0,
    name: 'الزخرفة النبوية',
    desc: 'التصميم الأصلي: نبيتي وذهبي مع زخارف إسلامية وبطاقات فخمة',
    icon: Icons.auto_awesome,
    seed: burgundy,
    primary: burgundy,
    highlight: gold,
    bg: Color(0xFFFFFCF3),
    card: Colors.white,
    ink: Color(0xFF1D1B1E),
    textAccent: burgundy,
  ),
  DesignSpec(
    id: 1,
    name: 'رفوف الخشب',
    desc: 'أرفف مكتبة خشبية تقف عليها الكتب، وكل كتاب بغلاف وكعب ملوّن',
    icon: Icons.collections_bookmark_outlined,
    seed: Color(0xFF5D3A1A),
    primary: Color(0xFF5D3A1A),
    highlight: Color(0xFFE8C98A),
    bg: Color(0xFFF3E7D3),
    card: Color(0xFFFFF8EA),
    ink: Color(0xFF3B2412),
    textAccent: Color(0xFF7A4A1E),
  ),
  DesignSpec(
    id: 2,
    name: 'الزمرّد العصري',
    desc: 'تصميم مسطّح هادئ: مربعات خضراء كبيرة وقوائم نظيفة بلا زخارف',
    icon: Icons.grid_view_rounded,
    seed: Color(0xFF0F6B4F),
    primary: Color(0xFF0F6B4F),
    highlight: Color(0xFFA7F3D0),
    bg: Color(0xFFF4F8F6),
    card: Colors.white,
    ink: Color(0xFF0B2A20),
    textAccent: Color(0xFF0F6B4F),
  ),
  DesignSpec(
    id: 3,
    name: 'الأزرق الملكي',
    desc: 'أقسام على شكل محراب تتنقل بينها بالتمرير، وكتب مرتبة على خط زمني',
    icon: Icons.mosque_outlined,
    seed: Color(0xFF14284B),
    primary: Color(0xFF14284B),
    highlight: Color(0xFF9ED8E8),
    bg: Color(0xFFEEF2F8),
    card: Colors.white,
    ink: Color(0xFF0E1B33),
    textAccent: Color(0xFF1F3F7A),
  ),
  DesignSpec(
    id: 4,
    name: 'الرمل والحبر',
    desc: 'تصميم تحريري كالمجلات: أرقام كبيرة وفهرس مرتب بخطوط رفيعة',
    icon: Icons.menu_book_outlined,
    seed: Color(0xFFB4532B),
    primary: Color(0xFF2B2118),
    highlight: Color(0xFFE08A5F),
    bg: Color(0xFFF6EFE3),
    card: Color(0xFFFBF7EF),
    ink: Color(0xFF2B2118),
    textAccent: Color(0xFFB4532B),
  ),
  DesignSpec(
    id: 5,
    name: 'الفحم والنحاس',
    desc: 'تصميم داكن فاخر: حلقات نحاسية وبلاطات مدمجة للكتب',
    icon: Icons.nights_stay_outlined,
    seed: Color(0xFFD08A4E),
    primary: Color(0xFF1C1C22),
    highlight: Color(0xFFD9955A),
    bg: Color(0xFF121216),
    card: Color(0xFF1C1C22),
    ink: Color(0xFFF3EDE6),
    textAccent: Color(0xFFD9955A),
    alwaysDark: true,
  ),
];

class DesignExt extends ThemeExtension<DesignExt> {
  final int id;
  final bool dark;
  final Color primary;
  final Color highlight;
  final Color bg;
  final Color card;
  final Color ink;
  final Color muted;
  final Color textAccent;
  const DesignExt({
    required this.id,
    required this.dark,
    required this.primary,
    required this.highlight,
    required this.bg,
    required this.card,
    required this.ink,
    required this.muted,
    required this.textAccent,
  });

  static DesignExt make(DesignSpec s, bool dark) {
    if (s.alwaysDark) {
      return DesignExt(id: s.id, dark: true, primary: s.primary, highlight: s.highlight, bg: s.bg, card: s.card, ink: s.ink, muted: const Color(0x99FFFFFF), textAccent: s.textAccent);
    }
    if (!dark) {
      return DesignExt(id: s.id, dark: false, primary: s.primary, highlight: s.highlight, bg: s.bg, card: s.card, ink: s.ink, muted: s.ink.withAlpha(158), textAccent: s.textAccent);
    }
    return DesignExt(
      id: s.id,
      dark: true,
      primary: s.primary,
      highlight: s.highlight,
      bg: s.id == 0 ? const Color(0xFF171417) : Color.lerp(Colors.black, s.primary, 0.16)!,
      card: s.id == 0 ? const Color(0xFF241F24) : Color.lerp(Colors.black, s.primary, 0.30)!,
      ink: const Color(0xFFF1ECE6),
      muted: const Color(0x99FFFFFF),
      textAccent: s.id == 0 ? gold : s.highlight,
    );
  }

  @override
  DesignExt copyWith() => this;

  @override
  DesignExt lerp(ThemeExtension<DesignExt>? other, double t) {
    if (other is! DesignExt) return this;
    return t < 0.5 ? this : other;
  }
}

DesignExt dx(BuildContext c) => Theme.of(c).extension<DesignExt>() ?? DesignExt.make(designSpecs[0], isDarkCtx(c));

// ════════════════════════════════════════════════════════════
//  وضع راحة العين
// ════════════════════════════════════════════════════════════

class EyeMode {
  final String name;
  final String sub;
  final IconData icon;
  final Color bg;
  final Color ink;
  final ColorFilter? filter;
  const EyeMode(this.name, this.sub, this.icon, this.bg, this.ink, this.filter);
}

const eyeModes = <EyeMode>[
  EyeMode('عادي', 'ألوان الكتاب الأصلية', Icons.wb_sunny_outlined, Color(0xFFFFFFFF), Color(0xFF222222), null),
  EyeMode('ورقي مريح', 'خلفية كريمية دافئة تخفف سطوع الأبيض', Icons.menu_book_outlined, Color(0xFFF4E6C8), Color(0xFF3A2E1E), ColorFilter.mode(Color(0xFFF4E6C8), BlendMode.multiply)),
  EyeMode(
    'ليلي',
    'خلفية داكنة وكتابة فاتحة دافئة للقراءة في الظلام',
    Icons.nightlight_round,
    Color(0xFF151311),
    Color(0xFFE1D2B9),
    ColorFilter.matrix(<double>[
      -0.80, 0, 0, 0, 225,
      0, -0.75, 0, 0, 210,
      0, 0, -0.66, 0, 185,
      0, 0, 0, 1, 0,
    ]),
  ),
  EyeMode('أخضر هادئ', 'درجة خضراء ناعمة تريح العين في القراءة الطويلة', Icons.eco_outlined, Color(0xFFD5E8CF), Color(0xFF22331E), ColorFilter.mode(Color(0xFFD5E8CF), BlendMode.multiply)),
  EyeMode('كهرماني دافئ', 'يقلل الضوء الأزرق ويناسب القراءة مساءً', Icons.wb_twilight, Color(0xFFFFE2B0), Color(0xFF4A3414), ColorFilter.mode(Color(0xFFFFE2B0), BlendMode.multiply)),
  EyeMode(
    'رمادي هادئ',
    'تدرّج رمادي خفيف يخفف تشبّع الألوان',
    Icons.contrast,
    Color(0xFFEBEBEB),
    Color(0xFF2A2A2A),
    ColorFilter.matrix(<double>[
      0.196, 0.658, 0.066, 0, 0,
      0.196, 0.658, 0.066, 0, 0,
      0.196, 0.658, 0.066, 0, 0,
      0, 0, 0, 1, 0,
    ]),
  ),
  EyeMode(
    'ليلي كهرماني',
    'خلفية سوداء وكتابة كهرمانية بلا ضوء أزرق، للنوم القريب',
    Icons.bedtime_outlined,
    Color(0xFF1A0C05),
    Color(0xFFCDAA78),
    ColorFilter.matrix(<double>[
      -0.70, 0, 0, 0, 205,
      0, -0.62, 0, 0, 170,
      0, 0, -0.45, 0, 120,
      0, 0, 0, 1, 0,
    ]),
  ),
];

ColorFilter? eyeFilter(int mode) {
  if (mode < 0 || mode >= eyeModes.length) return null;
  return eyeModes[mode].filter;
}

class AppPrefs {
  static final ValueNotifier<int> design = ValueNotifier<int>(0);
  static final ValueNotifier<int> eye = ValueNotifier<int>(0);
  static final ValueNotifier<bool> eyeAppWide = ValueNotifier<bool>(false);
  static bool _loaded = false;

  static Future<void> load() async {
    if (_loaded) return;
    _loaded = true;
    try {
      final p = await SharedPreferences.getInstance();
      final d = p.getInt('app_design') ?? 0;
      final e = p.getInt('read_mode') ?? 0;
      design.value = (d >= 0 && d < designSpecs.length) ? d : 0;
      eye.value = (e >= 0 && e < eyeModes.length) ? e : 0;
      eyeAppWide.value = p.getBool('eye_app_wide') ?? false;
    } catch (_) {}
  }

  static Future<void> setDesign(int v) async {
    design.value = v;
    try {
      final p = await SharedPreferences.getInstance();
      await p.setInt('app_design', v);
    } catch (_) {}
  }

  static Future<void> setEye(int v) async {
    eye.value = v;
    try {
      final p = await SharedPreferences.getInstance();
      await p.setInt('read_mode', v);
    } catch (_) {}
  }

  static Future<void> setAppWide(bool v) async {
    eyeAppWide.value = v;
    try {
      final p = await SharedPreferences.getInstance();
      await p.setBool('eye_app_wide', v);
    } catch (_) {}
  }
}

Widget _eyeTile(BuildContext ctx, DesignExt x, int i, int cur) {
  final e = eyeModes[i];
  return ListTile(
    leading: Container(
      width: 46,
      height: 46,
      alignment: Alignment.center,
      decoration: BoxDecoration(color: e.bg, borderRadius: BorderRadius.circular(12), border: Border.all(color: x.textAccent.withAlpha(90))),
      child: Text('أب', style: TextStyle(color: e.ink, fontWeight: FontWeight.bold, fontSize: 16)),
    ),
    title: Text(e.name),
    subtitle: Text(e.sub),
    trailing: cur == i ? Icon(Icons.check_circle, color: x.textAccent) : null,
    onTap: () {
      AppPrefs.setEye(i);
      Navigator.pop(ctx);
    },
  );
}

void showEyeModeSheet(BuildContext context) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (ctx) {
      final x = dx(ctx);
      return SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.84),
          child: ValueListenableBuilder<int>(
            valueListenable: AppPrefs.eye,
            builder: (ctx, cur, _) => ListView(
              shrinkWrap: true,
              padding: const EdgeInsets.only(bottom: 12),
              children: [
                const Padding(
                  padding: EdgeInsets.fromLTRB(18, 16, 18, 2),
                  child: Text('وضع راحة العين', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                ),
                const Padding(
                  padding: EdgeInsets.fromLTRB(18, 0, 18, 8),
                  child: Text('اختر الوضع الأنسب لعينيك. يُطبَّق على قراءة الكتب، ويمكنك تعميمه على التطبيق كله.', style: TextStyle(fontSize: 13, height: 1.6)),
                ),
                ValueListenableBuilder<bool>(
                  valueListenable: AppPrefs.eyeAppWide,
                  builder: (ctx, wide, _) => SwitchListTile(
                    secondary: const Icon(Icons.phone_android),
                    title: const Text('تطبيق الوضع على كامل التطبيق'),
                    subtitle: const Text('يشمل الرئيسية والمكتبة والقوائم، لا القراءة وحدها'),
                    value: wide,
                    onChanged: (v) => AppPrefs.setAppWide(v),
                  ),
                ),
                const Divider(height: 1),
                for (int i = 0; i < eyeModes.length; i++) _eyeTile(ctx, x, i, cur),
              ],
            ),
          ),
        ),
      );
    },
  );
}

// ════════════════════════════════════════════════════════════
//  صفحة اختيار التصميم
// ════════════════════════════════════════════════════════════

class DesignPage extends StatelessWidget {
  const DesignPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('التصميم')),
    body: ValueListenableBuilder<int>(
      valueListenable: AppPrefs.design,
      builder: (context, cur, _) => ListView(
        padding: const EdgeInsets.all(14),
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(4, 2, 4, 12),
            child: Text('اختر شكل المكتبة والأقسام والكتب. يتغير التصميم فورًا ويُحفظ للمرات القادمة.', style: TextStyle(fontSize: 13.5, height: 1.6)),
          ),
          for (final s in designSpecs) _DesignCard(spec: s, selected: s.id == cur),
        ],
      ),
    ),
  );
}

class _DesignCard extends StatelessWidget {
  final DesignSpec spec;
  final bool selected;
  const _DesignCard({required this.spec, required this.selected});

  Widget _dot(Color c) => Container(
    width: 18,
    height: 18,
    margin: const EdgeInsetsDirectional.only(end: 6),
    decoration: BoxDecoration(shape: BoxShape.circle, color: c, border: Border.all(color: const Color(0x33000000))),
  );

  @override
  Widget build(BuildContext context) {
    final x = dx(context);
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Material(
        color: x.card,
        clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: selected ? x.textAccent : x.ink.withAlpha(35), width: selected ? 2.2 : 1),
        ),
        child: InkWell(
          onTap: () => AppPrefs.setDesign(spec.id),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(children: [
              Container(
                width: 66,
                height: 66,
                decoration: BoxDecoration(color: spec.bg, borderRadius: BorderRadius.circular(14), border: Border.all(color: spec.ink.withAlpha(50))),
                child: Stack(children: [
                  Positioned(top: 8, left: 8, right: 8, height: 14, child: Container(decoration: BoxDecoration(color: spec.primary, borderRadius: BorderRadius.circular(5)))),
                  Positioned(top: 26, left: 8, width: 24, height: 6, child: Container(decoration: BoxDecoration(color: spec.highlight, borderRadius: BorderRadius.circular(3)))),
                  Positioned(bottom: 8, left: 8, right: 8, height: 22, child: Container(decoration: BoxDecoration(color: spec.card, borderRadius: BorderRadius.circular(6), border: Border.all(color: spec.textAccent.withAlpha(110))))),
                ]),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Icon(spec.icon, size: 18, color: x.textAccent),
                    const SizedBox(width: 6),
                    Expanded(child: Text(spec.name, style: TextStyle(color: x.ink, fontSize: 17, fontWeight: FontWeight.w800))),
                  ]),
                  const SizedBox(height: 4),
                  Text(spec.desc, style: TextStyle(color: x.muted, fontSize: 12.5, height: 1.55)),
                  const SizedBox(height: 8),
                  Row(children: [_dot(spec.primary), _dot(spec.highlight), _dot(spec.bg), _dot(spec.textAccent)]),
                ]),
              ),
              const SizedBox(width: 8),
              Icon(selected ? Icons.check_circle : Icons.radio_button_unchecked, color: selected ? x.textAccent : x.muted),
            ]),
          ),
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════
//  أدوات مشتركة
// ════════════════════════════════════════════════════════════

String categorySubtitle(String name) {
  if (name == 'العقيدة') return 'متون وشروح علم التوحيد';
  if (name == 'الفقه الشافعي') return 'متون وشروح ومناسك';
  return 'متون وشروح أصول الفقه';
}

void openCategory(BuildContext c, LibCategory cat) {
  Navigator.push(c, MaterialPageRoute(builder: (_) => BookListPage(title: cat.name, books: booksFor(cat.name))));
}

Widget _markLine(DesignExt x, int? mark, {double size = 13}) {
  if (mark != null) {
    return Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(Icons.bookmark, size: size + 1, color: x.textAccent),
      const SizedBox(width: 4),
      Text(marksLabel(mark), style: TextStyle(color: x.textAccent, fontSize: size, fontWeight: FontWeight.w700)),
    ]);
  }
  return Row(mainAxisSize: MainAxisSize.min, children: [
    Icon(Icons.picture_as_pdf_outlined, size: size + 1, color: x.muted),
    const SizedBox(width: 4),
    Text('PDF', style: TextStyle(color: x.muted, fontSize: size)),
  ]);
}

// ════════════════════════════════════════════════════════════
//  المكتبة (الأقسام) لكل تصميم
// ════════════════════════════════════════════════════════════

class DesignLibrary extends StatelessWidget {
  final DesignExt x;
  const DesignLibrary({super.key, required this.x});
  @override
  Widget build(BuildContext context) {
    switch (x.id) {
      case 1:
        return _woodLibrary(context, x);
      case 2:
        return _modernLibrary(context, x);
      case 3:
        return _NavyLibrary(x: x);
      case 4:
        return _inkLibrary(context, x);
      default:
        return _copperLibrary(context, x);
    }
  }
}

// ── ١) رفوف الخشب ──

class _Spines extends StatelessWidget {
  final int count;
  final int seed;
  const _Spines({required this.count, required this.seed});
  static const palette = <Color>[
    Color(0xFF7A2E2E),
    Color(0xFF2F4F3A),
    Color(0xFF2E3F63),
    Color(0xFF8A5A2B),
    Color(0xFF4F2F5E),
    Color(0xFF1F5A5A),
    Color(0xFF9A3A55),
  ];
  @override
  Widget build(BuildContext context) {
    final n = count > 14 ? 14 : count;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      mainAxisSize: MainAxisSize.min,
      children: [
        for (int i = 0; i < n; i++)
          Container(
            width: 11 + ((i * 7 + seed * 3) % 6).toDouble(),
            height: 40 + ((i * 13 + seed * 5) % 5) * 7.0,
            margin: const EdgeInsetsDirectional.only(end: 3),
            decoration: BoxDecoration(color: palette[(i + seed) % palette.length], borderRadius: const BorderRadius.vertical(top: Radius.circular(3))),
            child: Align(
              alignment: Alignment.topCenter,
              child: Container(margin: const EdgeInsets.only(top: 6), height: 2, width: 7, color: const Color(0x88FFFFFF)),
            ),
          ),
      ],
    );
  }
}

Widget _woodLibrary(BuildContext context, DesignExt x) {
  return ListView(
    padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
    children: [
      Center(child: Text('أرفف المكتبة', style: TextStyle(fontFamily: kDeco, fontWeight: FontWeight.w700, fontSize: 32, color: x.textAccent, height: 1.4))),
      Center(child: Text('اختر رفًّا لتصفّح كتبه', style: TextStyle(color: x.muted, fontSize: 13.5))),
      const SizedBox(height: 18),
      for (int i = 0; i < libCategories.length; i++) _shelf(context, x, libCategories[i], i),
    ],
  );
}

Widget _shelf(BuildContext context, DesignExt x, LibCategory c, int i) {
  final count = booksFor(c.name).length;
  return Padding(
    padding: const EdgeInsets.only(bottom: 22),
    child: InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: () => openCategory(context, c),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Container(
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 0),
          decoration: BoxDecoration(
            color: x.card,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
            border: Border.all(color: x.primary.withAlpha(70)),
          ),
          child: Column(children: [
            Row(children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(shape: BoxShape.circle, color: x.primary),
                child: Icon(c.icon, color: x.highlight, size: 28),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(c.name, style: TextStyle(fontFamily: kDeco, fontWeight: FontWeight.w700, fontSize: 26, color: x.ink, height: 1.3)),
                  Text('${categorySubtitle(c.name)} • ${booksLabel(count)}', style: TextStyle(color: x.muted, fontSize: 12.5)),
                ]),
              ),
              Icon(Icons.chevron_left, color: x.textAccent),
            ]),
            const SizedBox(height: 12),
            Align(alignment: AlignmentDirectional.centerStart, child: _Spines(count: count, seed: i)),
          ]),
        ),
        Container(
          height: 14,
          decoration: BoxDecoration(
            gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [x.primary, Color.lerp(x.primary, Colors.black, 0.35)!]),
            borderRadius: const BorderRadius.vertical(bottom: Radius.circular(6)),
          ),
        ),
      ]),
    ),
  );
}

// ── ٢) الزمرد العصري ──

Widget _modernTile(BuildContext context, DesignExt x, LibCategory c, Color tone, double h) {
  final count = booksFor(c.name).length;
  return Material(
    color: tone,
    borderRadius: BorderRadius.circular(28),
    clipBehavior: Clip.antiAlias,
    child: InkWell(
      onTap: () => openCategory(context, c),
      child: SizedBox(
        height: h,
        child: Stack(children: [
          Positioned(left: -18, bottom: -22, child: Icon(c.icon, size: h * 0.7, color: const Color(0x18FFFFFF))),
          Padding(
            padding: const EdgeInsets.all(18),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(color: const Color(0x2EFFFFFF), borderRadius: BorderRadius.circular(16)),
                child: Icon(c.icon, color: Colors.white),
              ),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(c.name, style: const TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w800, height: 1.3)),
                const SizedBox(height: 6),
                Text(booksLabel(count), style: TextStyle(color: x.highlight, fontSize: 13, fontWeight: FontWeight.w600)),
              ]),
            ]),
          ),
        ]),
      ),
    ),
  );
}

Widget _modernLibrary(BuildContext context, DesignExt x) {
  const tones = <Color>[Color(0xFF0F6B4F), Color(0xFF1C8C74), Color(0xFF0A4D3C)];
  final cats = libCategories;
  final rows = <Widget>[];
  for (int i = 0; i < cats.length; i += 2) {
    final pair = i + 1 < cats.length;
    rows.add(Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(children: [
        Expanded(child: _modernTile(context, x, cats[i], tones[i % 3], pair ? 190 : 130)),
        if (pair) const SizedBox(width: 12),
        if (pair) Expanded(child: _modernTile(context, x, cats[i + 1], tones[(i + 1) % 3], 190)),
      ]),
    ));
  }
  return ListView(
    padding: const EdgeInsets.fromLTRB(18, 12, 18, 28),
    children: [
      const SizedBox(height: 8),
      Text('المكتبة', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800, color: x.ink)),
      const SizedBox(height: 4),
      Text('اختر قسمًا لتصفّح كتبه', style: TextStyle(fontSize: 14, color: x.muted)),
      const SizedBox(height: 22),
      ...rows,
    ],
  );
}

// ── ٣) الأزرق الملكي (محراب متحرك) ──

class _NavyLibrary extends StatefulWidget {
  final DesignExt x;
  const _NavyLibrary({required this.x});
  @override
  State<_NavyLibrary> createState() => _NavyLibraryState();
}

class _NavyLibraryState extends State<_NavyLibrary> {
  final PageController pc = PageController(viewportFraction: 0.8);
  int cur = 0;

  @override
  void dispose() {
    pc.dispose();
    super.dispose();
  }

  Widget _arch(BuildContext context, DesignExt x, LibCategory c) {
    final count = booksFor(c.name).length;
    return GestureDetector(
      onTap: () => openCategory(context, c),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        decoration: BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [const Color(0xFF2A4A86), x.primary]),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(160), bottom: Radius.circular(30)),
          boxShadow: const [BoxShadow(color: Color(0x33000000), blurRadius: 12, offset: Offset(0, 5))],
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(children: [
          const Positioned.fill(child: CustomPaint(painter: PatternPainter(Color(0x149ED8E8)))),
          Positioned.fill(
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Container(
                decoration: BoxDecoration(
                  border: Border.all(color: x.highlight.withAlpha(110)),
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(150), bottom: Radius.circular(22)),
                ),
              ),
            ),
          ),
          Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 22),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Container(
                  width: 84,
                  height: 84,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0x229ED8E8), border: Border.all(color: x.highlight, width: 1.6)),
                  child: Icon(c.icon, color: x.highlight, size: 42),
                ),
                const SizedBox(height: 18),
                Text(c.name, textAlign: TextAlign.center, style: const TextStyle(fontFamily: kDeco, fontWeight: FontWeight.w700, fontSize: 34, color: Colors.white, height: 1.3)),
                const SizedBox(height: 6),
                Text(categorySubtitle(c.name), textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70, fontSize: 13.5)),
                const SizedBox(height: 14),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), border: Border.all(color: x.highlight.withAlpha(150))),
                  child: Text(booksLabel(count), style: TextStyle(color: x.highlight, fontSize: 13, fontWeight: FontWeight.w600)),
                ),
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 10),
                  decoration: BoxDecoration(color: x.highlight, borderRadius: BorderRadius.circular(24)),
                  child: Text('تصفّح الكتب', style: TextStyle(color: x.primary, fontWeight: FontWeight.w800, fontSize: 14)),
                ),
              ]),
            ),
          ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final x = widget.x;
    return Column(children: [
      const SizedBox(height: 14),
      Text('أقسام المكتبة', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: x.ink)),
      const SizedBox(height: 2),
      Text('مرّر يمينًا ويسارًا لاستعراض الأقسام', style: TextStyle(fontSize: 13, color: x.muted)),
      const SizedBox(height: 10),
      Expanded(
        child: PageView.builder(
          controller: pc,
          itemCount: libCategories.length,
          onPageChanged: (i) => setState(() => cur = i),
          itemBuilder: (context, i) => AnimatedBuilder(
            animation: pc,
            builder: (context, child) {
              double page = cur.toDouble();
              if (pc.hasClients && pc.position.haveDimensions) page = pc.page ?? page;
              final s = (1 - (page - i).abs() * 0.1).clamp(0.88, 1.0).toDouble();
              return Transform.scale(scale: s, child: child);
            },
            child: _arch(context, x, libCategories[i]),
          ),
        ),
      ),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        for (int i = 0; i < libCategories.length; i++)
          AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            width: i == cur ? 22 : 8,
            height: 8,
            margin: const EdgeInsets.symmetric(horizontal: 3),
            decoration: BoxDecoration(color: i == cur ? x.textAccent : x.ink.withAlpha(60), borderRadius: BorderRadius.circular(4)),
          ),
      ]),
      const SizedBox(height: 18),
    ]);
  }
}

// ── ٤) الرمل والحبر ──

Widget _inkRow(BuildContext context, DesignExt x, LibCategory c, int i) {
  final count = booksFor(c.name).length;
  return Column(children: [
    InkWell(
      onTap: () => openCategory(context, c),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 20),
        child: Row(children: [
          SizedBox(width: 80, child: Text('٠${ar(i + 1)}', style: TextStyle(fontSize: 52, fontWeight: FontWeight.w300, color: x.highlight, height: 1))),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(c.name, style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: x.ink, height: 1.3)),
              const SizedBox(height: 2),
              Text(categorySubtitle(c.name), style: TextStyle(fontSize: 13.5, color: x.muted)),
              const SizedBox(height: 8),
              Text(booksLabel(count), style: TextStyle(fontSize: 13, color: x.textAccent, fontWeight: FontWeight.w700)),
            ]),
          ),
          Icon(Icons.chevron_left, color: x.ink),
        ]),
      ),
    ),
    Divider(height: 1, color: x.ink.withAlpha(50)),
  ]);
}

Widget _inkLibrary(BuildContext context, DesignExt x) {
  return ListView(
    padding: const EdgeInsets.fromLTRB(20, 14, 20, 30),
    children: [
      Text('المكتبة', style: TextStyle(fontSize: 42, fontWeight: FontWeight.w900, color: x.ink, height: 1.2)),
      const SizedBox(height: 2),
      Text('أقسام العلم الشرعي', style: TextStyle(fontSize: 14, color: x.textAccent, fontWeight: FontWeight.w700)),
      const SizedBox(height: 14),
      Container(height: 3, color: x.ink),
      for (int i = 0; i < libCategories.length; i++) _inkRow(context, x, libCategories[i], i),
    ],
  );
}

// ── ٥) الفحم والنحاس ──

Widget _copperCard(BuildContext context, DesignExt x, LibCategory c) {
  final count = booksFor(c.name).length;
  return Padding(
    padding: const EdgeInsets.only(bottom: 14),
    child: Material(
      color: x.card,
      borderRadius: BorderRadius.circular(22),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => openCategory(context, c),
        child: SizedBox(
          height: 118,
          child: Stack(children: [
            Positioned(top: 0, bottom: 0, right: 0, width: 6, child: Container(color: x.textAccent)),
            Positioned(left: -20, bottom: -26, child: Icon(c.icon, size: 120, color: x.textAccent.withAlpha(22))),
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 0, 22, 0),
              child: Row(children: [
                SizedBox(
                  width: 72,
                  height: 72,
                  child: Stack(alignment: Alignment.center, children: [
                    Positioned.fill(child: CircularProgressIndicator(value: 1, strokeWidth: 3, color: x.textAccent, backgroundColor: x.textAccent.withAlpha(50))),
                    Text(ar(count), style: TextStyle(color: x.textAccent, fontSize: 24, fontWeight: FontWeight.bold, fontFamily: kDeco)),
                  ]),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(c.name, style: TextStyle(color: x.ink, fontSize: 22, fontWeight: FontWeight.w800, height: 1.3)),
                    const SizedBox(height: 2),
                    Text(categorySubtitle(c.name), style: TextStyle(color: x.muted, fontSize: 13)),
                  ]),
                ),
                Icon(Icons.chevron_left, color: x.textAccent),
              ]),
            ),
          ]),
        ),
      ),
    ),
  );
}

Widget _copperLibrary(BuildContext context, DesignExt x) {
  return ListView(
    padding: const EdgeInsets.fromLTRB(16, 14, 16, 28),
    children: [
      Text('المكتبة', style: TextStyle(fontFamily: kDeco, fontSize: 34, fontWeight: FontWeight.w700, color: x.textAccent)),
      const SizedBox(height: 4),
      Text('اختر قسمًا لتصفّح كتبه', style: TextStyle(color: x.muted, fontSize: 13.5)),
      const SizedBox(height: 18),
      for (final c in libCategories) _copperCard(context, x, c),
    ],
  );
}

// ════════════════════════════════════════════════════════════
//  قائمة كتب القسم لكل تصميم
// ════════════════════════════════════════════════════════════

Widget _woodCover(DesignExt x, Book b, int idx, int? mark, VoidCallback onTap) {
  final base = _Spines.palette[idx % _Spines.palette.length];
  final spine = Color.lerp(base, Colors.black, 0.35)!;
  return Material(
    color: base,
    elevation: 4,
    shadowColor: Colors.black54,
    borderRadius: const BorderRadius.only(topRight: Radius.circular(6), bottomRight: Radius.circular(6), topLeft: Radius.circular(14), bottomLeft: Radius.circular(14)),
    clipBehavior: Clip.antiAlias,
    child: InkWell(
      onTap: onTap,
      child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Container(width: 16, color: spine),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
              decoration: BoxDecoration(border: Border.all(color: const Color(0x88E8C98A)), borderRadius: BorderRadius.circular(8)),
              child: Column(children: [
                Text(ar(idx + 1), style: const TextStyle(color: Color(0xFFE8C98A), fontWeight: FontWeight.bold, fontSize: 15)),
                Expanded(
                  child: Center(
                    child: Text(b.title, textAlign: TextAlign.center, maxLines: 6, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 12.5, fontWeight: FontWeight.w700, height: 1.5)),
                  ),
                ),
                Icon(mark != null ? Icons.bookmark : Icons.picture_as_pdf_outlined, size: 16, color: mark != null ? const Color(0xFFE8C98A) : Colors.white70),
                if (mark != null) Text(marksLabel(mark), style: const TextStyle(color: Color(0xFFE8C98A), fontSize: 10.5)),
              ]),
            ),
          ),
        ),
      ]),
    ),
  );
}

Widget _modernItem(DesignExt x, Book b, int idx, int? mark, VoidCallback onTap) {
  return InkWell(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(border: Border(bottom: BorderSide(color: x.ink.withAlpha(25)))),
      child: Row(children: [
        Container(
          width: 48,
          height: 48,
          alignment: Alignment.center,
          decoration: BoxDecoration(color: x.primary.withAlpha(30), borderRadius: BorderRadius.circular(14)),
          child: Text(ar(idx + 1), style: TextStyle(color: x.textAccent, fontWeight: FontWeight.w800, fontSize: 16)),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(b.title, maxLines: 3, overflow: TextOverflow.ellipsis, style: TextStyle(color: x.ink, fontWeight: FontWeight.w600, fontSize: 15.5, height: 1.5)),
            const SizedBox(height: 4),
            _markLine(x, mark, size: 12.5),
          ]),
        ),
        Icon(Icons.chevron_left, color: x.textAccent),
      ]),
    ),
  );
}

Widget _navyItem(DesignExt x, Book b, int idx, int? mark, bool last, VoidCallback onTap) {
  return IntrinsicHeight(
    child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      SizedBox(
        width: 40,
        child: Column(children: [
          Container(
            width: 34,
            height: 34,
            alignment: Alignment.center,
            decoration: BoxDecoration(shape: BoxShape.circle, color: x.primary, border: Border.all(color: x.highlight, width: 2)),
            child: Text(ar(idx + 1), style: const TextStyle(color: Colors.white, fontSize: 12.5, fontWeight: FontWeight.bold)),
          ),
          if (!last) Expanded(child: Container(width: 2, color: x.primary.withAlpha(70))),
        ]),
      ),
      const SizedBox(width: 8),
      Expanded(
        child: Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Material(
            color: x.card,
            elevation: 1.5,
            shadowColor: Colors.black38,
            borderRadius: BorderRadius.circular(16),
            clipBehavior: Clip.antiAlias,
            child: InkWell(
              onTap: onTap,
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(b.title, maxLines: 3, overflow: TextOverflow.ellipsis, style: TextStyle(color: x.ink, fontWeight: FontWeight.w700, fontSize: 15, height: 1.5)),
                  const SizedBox(height: 8),
                  _markLine(x, mark, size: 12.5),
                ]),
              ),
            ),
          ),
        ),
      ),
    ]),
  );
}

Widget _inkItem(DesignExt x, Book b, int idx, int? mark, VoidCallback onTap) {
  return Column(children: [
    InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 14),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SizedBox(width: 46, child: Text(ar(idx + 1), style: TextStyle(color: x.textAccent, fontWeight: FontWeight.w800, fontSize: 20, height: 1.3))),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(b.title, style: TextStyle(color: x.ink, fontWeight: FontWeight.w700, fontSize: 16, height: 1.55)),
              const SizedBox(height: 4),
              _markLine(x, mark, size: 12.5),
            ]),
          ),
          Padding(padding: const EdgeInsets.only(top: 4), child: Icon(Icons.chevron_left, size: 20, color: x.ink)),
        ]),
      ),
    ),
    Divider(height: 1, color: x.ink.withAlpha(45)),
  ]);
}

Widget _copperTile(DesignExt x, Book b, int idx, int? mark, VoidCallback onTap) {
  return Material(
    color: x.card,
    borderRadius: BorderRadius.circular(16),
    clipBehavior: Clip.antiAlias,
    child: InkWell(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), border: Border.all(color: x.textAccent.withAlpha(70))),
        padding: const EdgeInsets.all(10),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(ar(idx + 1), style: TextStyle(fontFamily: kDeco, fontSize: 24, fontWeight: FontWeight.w700, color: x.textAccent, height: 1.1)),
          Container(height: 2, width: 22, margin: const EdgeInsets.symmetric(vertical: 6), color: x.textAccent.withAlpha(120)),
          Expanded(child: Text(b.title, maxLines: 7, overflow: TextOverflow.ellipsis, style: TextStyle(color: x.ink, fontSize: 11.5, fontWeight: FontWeight.w600, height: 1.5))),
          const SizedBox(height: 4),
          Row(children: [
            Icon(mark != null ? Icons.bookmark : Icons.picture_as_pdf_outlined, size: 14, color: x.textAccent),
            const SizedBox(width: 4),
            Text(mark != null ? ar(mark) : 'PDF', style: TextStyle(color: x.muted, fontSize: 11)),
          ]),
        ]),
      ),
    ),
  );
}

Widget _listHeader(DesignExt x, String title, int n, int totalMarks) {
  final sub = totalMarks == 0 ? 'اضغط على أي كتاب لبدء القراءة.' : 'لديك ${marksLabel(totalMarks)} محفوظة.';
  switch (x.id) {
    case 1:
      return Container(
        margin: const EdgeInsets.only(bottom: 14),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: x.card, borderRadius: BorderRadius.circular(14), border: Border.all(color: x.primary.withAlpha(70))),
        child: Row(children: [
          Icon(Icons.collections_bookmark, color: x.primary, size: 30),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(booksLabel(n), style: TextStyle(color: x.ink, fontWeight: FontWeight.w800, fontSize: 17)),
              Text(sub, style: TextStyle(color: x.muted, fontSize: 12.5)),
            ]),
          ),
        ]),
      );
    case 2:
      return Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800, color: x.ink)),
          const SizedBox(height: 2),
          Text('${booksLabel(n)} • $sub', style: TextStyle(fontSize: 13.5, color: x.textAccent, fontWeight: FontWeight.w600)),
        ]),
      );
    case 3:
      return Container(
        margin: const EdgeInsets.only(bottom: 14),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [const Color(0xFF2A4A86), x.primary]),
          borderRadius: BorderRadius.circular(22),
        ),
        child: Row(children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0x229ED8E8), border: Border.all(color: x.highlight)),
            child: Icon(Icons.auto_stories, color: x.highlight),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(booksLabel(n), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 19)),
              Text(sub, style: const TextStyle(color: Colors.white70, fontSize: 12.5)),
            ]),
          ),
        ]),
      );
    case 4:
      return Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('فهرس الكتب', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900, color: x.ink)),
          const SizedBox(height: 2),
          Text('${booksLabel(n)} • $sub', style: TextStyle(fontSize: 13.5, color: x.textAccent, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          Container(height: 3, color: x.ink),
        ]),
      );
    default:
      return Container(
        margin: const EdgeInsets.only(bottom: 14),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: x.card, borderRadius: BorderRadius.circular(18), border: Border.all(color: x.textAccent.withAlpha(90))),
        child: Row(children: [
          Icon(Icons.library_books, color: x.textAccent, size: 34),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(booksLabel(n), style: TextStyle(color: x.ink, fontWeight: FontWeight.w800, fontSize: 18)),
              Text(sub, style: TextStyle(color: x.muted, fontSize: 12.5)),
            ]),
          ),
        ]),
      );
  }
}

Widget _searchBox(DesignExt x, TextEditingController ctl, String q, ValueChanged<String> onQuery) {
  final r = x.id == 1 ? 12.0 : (x.id == 2 ? 30.0 : (x.id == 3 ? 16.0 : (x.id == 4 ? 4.0 : 18.0)));
  return TextField(
    controller: ctl,
    onChanged: onQuery,
    style: TextStyle(color: x.ink),
    decoration: InputDecoration(
      hintText: 'ابحث في هذا القسم...',
      hintStyle: TextStyle(color: x.muted),
      prefixIcon: Icon(Icons.search, color: x.textAccent),
      suffixIcon: q.isEmpty
          ? null
          : IconButton(
              icon: Icon(Icons.close, color: x.muted),
              onPressed: () {
                ctl.clear();
                onQuery('');
              },
            ),
      filled: true,
      fillColor: x.card,
      contentPadding: EdgeInsets.zero,
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(r), borderSide: BorderSide(color: x.textAccent.withAlpha(80))),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(r), borderSide: BorderSide(color: x.textAccent, width: 1.6)),
    ),
  );
}

Scaffold designBookListScaffold(
  BuildContext context,
  DesignExt x, {
  required String title,
  required List<Book> all,
  required List<int> shown,
  required Map<String, int> marks,
  required String q,
  required TextEditingController ctl,
  required ValueChanged<String> onQuery,
  required Future<void> Function(Book) onOpen,
  List<Widget>? actions,
}) {
  final totalMarks = marks.values.fold<int>(0, (a, b) => a + b);
  final barColored = x.id == 1 || x.id == 3;
  Color fg;
  if (x.id == 1) {
    fg = x.highlight;
  } else if (x.id == 3) {
    fg = Colors.white;
  } else if (x.id == 5) {
    fg = x.textAccent;
  } else {
    fg = x.ink;
  }
  final appBar = AppBar(
    backgroundColor: barColored ? x.primary : x.bg,
    foregroundColor: fg,
    actions: actions,
    elevation: 0,
    scrolledUnderElevation: 0,
    centerTitle: x.id != 2 && x.id != 4,
    title: Text(title, style: TextStyle(fontFamily: (x.id == 1 || x.id == 5) ? kDeco : null, fontWeight: FontWeight.w700, fontSize: 22)),
  );

  final slivers = <Widget>[
    SliverToBoxAdapter(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          _listHeader(x, title, all.length, totalMarks),
          _searchBox(x, ctl, q, onQuery),
          const SizedBox(height: 14),
        ]),
      ),
    ),
  ];

  if (shown.isEmpty) {
    slivers.add(SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.all(30), child: Center(child: Text('لا توجد كتب مطابقة.', style: TextStyle(color: x.muted))))));
  } else if (x.id == 1 || x.id == 5) {
    final wood = x.id == 1;
    slivers.add(SliverPadding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 28),
      sliver: SliverGrid(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: wood ? 2 : 3,
          mainAxisSpacing: wood ? 16 : 10,
          crossAxisSpacing: wood ? 16 : 10,
          childAspectRatio: wood ? 0.74 : 0.6,
        ),
        delegate: SliverChildBuilderDelegate((c, i) {
          final idx = shown[i];
          final b = all[idx];
          final mark = marks[b.asset];
          return wood ? _woodCover(x, b, idx, mark, () => onOpen(b)) : _copperTile(x, b, idx, mark, () => onOpen(b));
        }, childCount: shown.length),
      ),
    ));
  } else {
    slivers.add(SliverPadding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 28),
      sliver: SliverList(
        delegate: SliverChildBuilderDelegate((c, i) {
          final idx = shown[i];
          final b = all[idx];
          final mark = marks[b.asset];
          if (x.id == 2) return _modernItem(x, b, idx, mark, () => onOpen(b));
          if (x.id == 3) return _navyItem(x, b, idx, mark, i == shown.length - 1, () => onOpen(b));
          return _inkItem(x, b, idx, mark, () => onOpen(b));
        }, childCount: shown.length),
      ),
    ));
  }

  return Scaffold(
    backgroundColor: x.bg,
    appBar: appBar,
    body: CustomScrollView(slivers: slivers),
  );
}
