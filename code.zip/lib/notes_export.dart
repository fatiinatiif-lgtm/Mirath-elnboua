import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:flutter/services.dart';
import 'package:image/image.dart' as img;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart' show PdfColor, PdfColors, PdfPageFormat;
import 'package:pdf/widgets.dart' as pw;
import 'package:pdfrx/pdfrx.dart' show PdfDocument;
import 'main.dart';

const _hlRgb = <int>[0xFFF176, 0xAED581, 0xF8BBD0, 0x81D4FA, 0xFFCC80, 0xCE93D8, 0xEF9A9A];

/// يرسم الجزء الملوّن من الصفحة كصورة JPEG (مع التلوين فوقه).
/// نستخدم dynamic عمدًا حتى لا يتعطل البناء لو اختلفت تفاصيل مكتبة pdfrx؛ وعند أي خطأ نكتفي بالنص.
Future<Uint8List?> _cropImage(PdfDocument doc, Hl h) async {
  try {
    final pg = doc.pages[h.page - 1];
    const fw = 1000.0;
    final fh = fw * pg.height / pg.width;
    final top = (h.rect.top - 0.015).clamp(0.0, 0.95).toDouble();
    final bottom = (h.rect.bottom + 0.015).clamp(top + 0.05, 1.0).toDouble();
    final y = (top * fh).floor();
    final hh = math.max(20, ((bottom - top) * fh).ceil());
    final dynamic im = await (pg as dynamic).render(x: 0, y: y, width: 1000, height: hh, fullWidth: fw, fullHeight: fh);
    if (im == null) return null;
    final int w = im.width as int;
    final int hgt = im.height as int;
    final Uint8List px = im.pixels as Uint8List;
    final out = Uint8List(w * hgt * 4);
    final rl = (h.rect.left * w).round();
    final rr = (h.rect.right * w).round();
    final rt = (h.rect.top * fh - y).round();
    final rb = (h.rect.bottom * fh - y).round();
    final c = _hlRgb[h.color];
    final cr = (c >> 16) & 255, cg = (c >> 8) & 255, cb = c & 255;
    for (int j = 0; j < hgt; j++) {
      for (int i = 0; i < w; i++) {
        final o = (j * w + i) * 4;
        int r = px[o + 2], g = px[o + 1], b = px[o];
        if (i >= rl && i < rr && j >= rt && j < rb) {
          r = (r * cr / 255).round();
          g = (g * cg / 255).round();
          b = (b * cb / 255).round();
        }
        out[o] = r;
        out[o + 1] = g;
        out[o + 2] = b;
        out[o + 3] = 255;
      }
    }
    try {
      im.dispose();
    } catch (_) {}
    final image = img.Image.fromBytes(width: w, height: hgt, bytes: out.buffer, numChannels: 4);
    return Uint8List.fromList(img.encodeJpg(image, quality: 85));
  } catch (_) {
    return null;
  }
}

pw.Widget _t(String s, {double size = 12, bool bold = false, PdfColor? color, pw.TextAlign align = pw.TextAlign.right}) => pw.Text(
      s,
      textDirection: pw.TextDirection.rtl,
      textAlign: align,
      style: pw.TextStyle(fontSize: size, fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal, color: color, lineSpacing: 3),
    );

String _date(DateTime d) => '${ar(d.day)} / ${ar(d.month)} / ${ar(d.year)}';

Future<File> buildNotesPdf(Book book, List<Hl> hls, PdfDocument doc) async {
  final reg = pw.Font.ttf(await rootBundle.load('assets/pdffont/DejaVuSans.ttf'));
  final bold = pw.Font.ttf(await rootBundle.load('assets/pdffont/DejaVuSans-Bold.ttf'));
  final sorted = [...hls]..sort((a, b) {
      final c = a.page.compareTo(b.page);
      return c != 0 ? c : a.rect.top.compareTo(b.rect.top);
    });
  final images = <Uint8List?>[];
  for (final h in sorted) {
    images.add(await _cropImage(doc, h));
  }
  const maroon = PdfColor.fromInt(0xFF681B32);
  final pdf = pw.Document();
  pdf.addPage(pw.MultiPage(
    pageTheme: pw.PageTheme(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(32),
      textDirection: pw.TextDirection.rtl,
      theme: pw.ThemeData.withFont(base: reg, bold: bold),
    ),
    footer: (ctx) => pw.Padding(
      padding: const pw.EdgeInsets.only(top: 8),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          _t('ميراث النبوة', size: 9, color: PdfColors.grey600),
          _t(ar(ctx.pageNumber), size: 9, color: PdfColors.grey600),
        ],
      ),
    ),
    build: (ctx) => [
      _t(book.title, size: 18, bold: true, color: maroon, align: pw.TextAlign.center),
      pw.SizedBox(height: 4),
      _t('ملحوظاتي وتلويناتي · ${ar(sorted.length)} · ${_date(DateTime.now())}', size: 11, color: PdfColors.grey700, align: pw.TextAlign.center),
      pw.SizedBox(height: 6),
      pw.Divider(color: maroon, thickness: 1.2),
      pw.SizedBox(height: 10),
      for (int i = 0; i < sorted.length; i++)
        pw.Padding(
          padding: const pw.EdgeInsets.only(bottom: 16),
          child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.stretch, children: [
            pw.Row(children: [
              pw.Container(width: 11, height: 11, decoration: pw.BoxDecoration(color: PdfColor.fromInt(0xFF000000 | _hlRgb[sorted[i].color]), shape: pw.BoxShape.circle)),
              pw.SizedBox(width: 6),
              _t('صفحة ${ar(sorted[i].page)} · ${hlNames[sorted[i].color]}', size: 12, bold: true),
            ]),
            pw.SizedBox(height: 6),
            if (images[i] != null)
              pw.Container(
                constraints: const pw.BoxConstraints(maxHeight: 520),
                decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey400, width: 0.6)),
                child: pw.Image(pw.MemoryImage(images[i]!), fit: pw.BoxFit.contain),
              ),
            if (sorted[i].note.isNotEmpty) ...[
              pw.SizedBox(height: 6),
              pw.Container(
                padding: const pw.EdgeInsets.all(8),
                decoration: pw.BoxDecoration(color: PdfColors.grey100, border: pw.Border.all(color: PdfColors.grey400, width: 0.6)),
                child: _t(sorted[i].note, size: 12),
              ),
            ],
          ]),
        ),
    ],
  ));
  final dir = await getTemporaryDirectory();
  final base = book.asset.split('/').last.replaceAll('.pdf', '');
  final file = File('${dir.path}/notes_$base.pdf');
  await file.writeAsBytes(await pdf.save());
  return file;
}
