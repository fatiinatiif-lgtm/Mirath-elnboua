import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:pdfrx/pdfrx.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const MirathApp());

const burgundy = Color(0xFF681B32);
const gold = Color(0xFFE4B83F);

class Book {
  final String title;
  final String asset;
  const Book(this.title, this.asset);
}

const creedBooks = <Book>[
  Book('منظومة عقيدة العوام للشيخ أحمد المرزوقي المكي', 'assets/books/01_aqidat_al_awam.pdf'),
  Book('منظومة جوهرة التوحيد للإمام برهان الدين إبراهيم اللقاني', 'assets/books/02_jawharat_al_tawhid.pdf'),
  Book('متن الخريدة البهية', 'assets/books/03_al_kharida_al_bahiyya.pdf'),
  Book('قصيدة بدء الأمالي للشيخ علي بن عثمان الأوشي', 'assets/books/04_bad_al_amali.pdf'),
  Book('منظومة إضاءة الدجنة في اعتقاد أهل السنة للعلامة أحمد المقري المغربي', 'assets/books/05_idaat_al_dujunna.pdf'),
  Book('متن قواعد العقائد للإمام أبي حامد الغزالي', 'assets/books/06_qawaid_al_aqaid.pdf'),
  Book('متن صغرى الصغرى للإمام أبي عبدالله محمد بن يوسف السنوسي', 'assets/books/07_sanusi_sughra_al_sughra.pdf'),
  Book('العقيدة الصغرى أم البراهين للإمام أبي عبدالله محمد بن يوسف السنوسي', 'assets/books/08_sanusi_umm_al_barahin.pdf'),
  Book('متن الحفيدة للإمام أبي عبدالله محمد بن يوسف السنوسي', 'assets/books/09_sanusi_hafida.pdf'),
  Book('متن المقدمات للإمام أبي عبدالله محمد بن يوسف السنوسي', 'assets/books/10_matn_al_muqaddimat.pdf'),
  Book('متن العقيدة الوسطى للإمام أبي عبدالله محمد بن يوسف السنوسي', 'assets/books/11_sanusi_wusta.pdf'),
  Book('العقيدة الكبرى للإمام أبي عبدالله محمد بن يوسف السنوسي', 'assets/books/12_sanusi_kubra.pdf'),
  Book('العقيدة الطحاوية للإمام أحمد بن محمد الطحاوي', 'assets/books/13_al_tahawiyya.pdf'),
  Book('متن العقيدة النسفية للإمام عمر بن محمد النسفي', 'assets/books/14_al_nasafiyya.pdf'),
  Book('متن العقيدة التوحيدية للعلامة أبي البركات أحمد بن أحمد الدردير', 'assets/books/15_al_tawhidiyya_dardir.pdf'),
  Book('عقيدة أهل الإسلام للإمام عبدالله بن علوي الحداد', 'assets/books/16_aqidat_ahl_al_islam.pdf'),
  Book('كفاية العوام فيما يجب عليهم من علم الكلام للشيخ محمد الفضالي الشافعي', 'assets/books/17_kifayat_al_awam.pdf'),
  Book('الاقتصاد في الاعتقاد لحجة الإسلام محمد بن محمد الغزالي', 'assets/books/18_al_iqtisad_fil_itiqad.pdf'),
  Book('متن العقائد العضدية للإمام عضد الدين عبدالرحمن بن أحمد الإيجي', 'assets/books/19_al_adudiyya.pdf'),
  Book('دروس التوحيد للعلامة محمد بن أحمد الشاطري', 'assets/books/20_duroos_tawhid_shatiri.pdf'),
  Book('متن دروس التوحيد للعلامة محمد بن سالم بن حفيظ', 'assets/books/21_matn_duroos_tawhid_hafiz.pdf'),
  Book('رسالة في علم التوحيد للعلامة إبراهيم بن محمد الباجوري', 'assets/books/22_risala_ilm_tawhid_bajuri.pdf'),
  Book('عقيدة السلطان محمد الفاتح جواهر العقائد للعلامة المولى خضر بك بن', 'assets/books/23_aqidat_al_fatih.pdf'),
];

const creedSharhBooks = <Book>[
  Book('الروضة الندية شرح العقيدة الطحاوية', 'assets/books/aqeeda_s_01_al_rawda_al_nadiyya_sharh_al_tahawiyya.pdf'),
];

const fiqhMatnBooks = <Book>[
  Book('مختصر أبي شجاع المسمى متن الغاية والتقريب أو غاية الاختصار', 'assets/books/fiqh_m_01_mukhtasar_abi_shuja_ghayat_al_ikhtisar.pdf'),
  Book('متن سفينة النجاة', 'assets/books/fiqh_m_02_matn_safinat_al_naja.pdf'),
  Book('المقدمة الحضرمية', 'assets/books/fiqh_m_03_al_muqaddima_al_hadramiyya.pdf'),
  Book('اللباب في الفقه الشّافعي', 'assets/books/fiqh_m_04_al_lubab_fil_fiqh_al_shafii.pdf'),
  Book('متن صفوة نظم الزبد', 'assets/books/fiqh_m_05_matn_safwat_nazm_al_zubad.pdf'),
  Book('الشافي الأنيس في نظم ياقوت النفيس', 'assets/books/fiqh_m_06_al_shafi_al_anis_nazm_yaqut_al_nafis.pdf'),
  Book('منظومة تحفة الشافعية', 'assets/books/fiqh_m_07_manzumat_tuhfat_al_shafiiyya.pdf'),
  Book('نهاية التدريب نظم غاية التقريب النسخة المعتمدة', 'assets/books/fiqh_m_08_nihayat_al_tadrib_nazm_ghayat_al_taqrib.pdf'),
  Book('نهاية التدريب في نظم غاية التقريب', 'assets/books/fiqh_m_09_nihayat_al_tadrib_fi_nazm_ghayat_al_taqrib.pdf'),
  Book('التّيسير نظم التّحرير', 'assets/books/fiqh_m_10_al_taysir_nazm_al_tahrir.pdf'),
];

const fiqhSharhBooks = <Book>[
  Book('فتح القريب المجيب', 'assets/books/fiqh_s_01_fath_al_qarib_al_mujib.pdf'),
  Book('شرح متن الغاية والتقريب', 'assets/books/fiqh_s_02_sharh_matn_al_ghaya_wal_taqrib.pdf'),
  Book('النهاية في شرح الغاية', 'assets/books/fiqh_s_03_al_nihaya_fi_sharh_al_ghaya.pdf'),
  Book('الت ذهيب في أدلة متن الغاية', 'assets/books/fiqh_s_04_al_tadhhib_fi_adillat_matn_al_ghaya.pdf'),
  Book('تشجير متن الغاية والتقريب', 'assets/books/fiqh_s_05_tashjir_matn_al_ghaya_wal_taqrib.pdf'),
  Book('المعتمد عند الشافعية', 'assets/books/fiqh_s_06_al_mutamad_inda_al_shafiiyya.pdf'),
  Book('المفطرات المعاصرة عند الشافعية', 'assets/books/fiqh_s_07_al_mufattirat_al_muasira.pdf'),
  Book('الإقناع', 'assets/books/fiqh_s_08_al_iqna.pdf'),
  Book('المفرد لألفاظ الزبد', 'assets/books/fiqh_s_09_al_mufrad_li_alfaz_al_zubad.pdf'),
  Book('فتح الصمد شرح الزبد لابن زياد الوضاحي تحقيق العامري', 'assets/books/fiqh_s_10_fath_al_samad_sharh_al_zubad.pdf'),
  Book('مواهب الصمد في حل الفاظ الزبد لأحمد بن حجازي الفشني طبعة مكتبة دار', 'assets/books/fiqh_s_11_mawahib_al_samad_fi_hall_alfaz_al_zubad.pdf'),
  Book('فتح القدير الخبير بشرح تيسير التحرير', 'assets/books/fiqh_s_12_fath_al_qadir_al_khabir.pdf'),
  Book('تحرير تنقيح اللباب', 'assets/books/fiqh_s_13_tahrir_tanqih_al_lubab.pdf'),
];

final allBooks = <Book>[...creedBooks, ...creedSharhBooks, ...fiqhMatnBooks, ...fiqhSharhBooks];

class MirathApp extends StatefulWidget {
  const MirathApp({super.key});
  @override
  State<MirathApp> createState() => _MirathAppState();
}

class _MirathAppState extends State<MirathApp> {
  bool dark = false;
  bool started = false;
  @override
  Widget build(BuildContext context) {
    final scheme = ColorScheme.fromSeed(
      seedColor: burgundy,
      brightness: dark ? Brightness.dark : Brightness.light,
      primary: burgundy,
      secondary: gold,
    );
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child!),
      title: 'ميراث النبوة',
      theme: ThemeData(colorScheme: scheme, useMaterial3: true, scaffoldBackgroundColor: dark ? const Color(0xFF171417) : const Color(0xFFFFFCF3), appBarTheme: const AppBarTheme(centerTitle: true)),
      home: started ? MainShell(dark: dark, onThemeChanged: (v) => setState(() => dark = v)) : SplashScreen(onDone: () => setState(() => started = true)),
    );
  }
}

class SplashScreen extends StatefulWidget {
  final VoidCallback onDone;
  const SplashScreen({super.key, required this.onDone});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}
class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  static const words = ['بسم', 'الله', 'الرحمن', 'الرحيم'];
  late final AnimationController c;
  @override
  void initState() {
    super.initState();
    c = AnimationController(vsync: this, duration: const Duration(seconds: 5));
    c.addStatusListener((st) {
      if (st == AnimationStatus.completed && mounted) widget.onDone();
    });
    c.forward();
  }
  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: burgundy,
    body: Center(
      child: AnimatedBuilder(
        animation: c,
        builder: (context, _) {
          final t = c.value;
          final idx = (t * words.length).floor().clamp(0, words.length - 1);
          final f = t * words.length - idx;
          final opacity = f < 0.25 ? f / 0.25 : (f > 0.75 ? (1 - f) / 0.25 : 1.0);
          final remaining = (5 - (t * 5).floor()).clamp(1, 5);
          return Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.auto_stories_rounded, color: gold, size: 66),
            const SizedBox(height: 20),
            const Text('ميراث', style: TextStyle(color: gold, fontSize: 42, fontWeight: FontWeight.bold)),
            const Text('النبوة', style: TextStyle(color: Colors.white, fontSize: 38, fontWeight: FontWeight.w600)),
            const SizedBox(height: 28),
            Container(width: 90, height: 2, color: gold),
            const SizedBox(height: 34),
            SizedBox(
              height: 64,
              child: Center(
                child: Opacity(
                  opacity: opacity.clamp(0.0, 1.0),
                  child: Text(words[idx], style: const TextStyle(color: Colors.white, fontSize: 40, fontWeight: FontWeight.bold)),
                ),
              ),
            ),
            const SizedBox(height: 34),
            SizedBox(
              width: 70,
              height: 70,
              child: Stack(alignment: Alignment.center, children: [
                SizedBox(width: 70, height: 70, child: CircularProgressIndicator(value: t, strokeWidth: 4, color: gold, backgroundColor: Colors.white24)),
                Text(ar(remaining), style: const TextStyle(color: gold, fontSize: 28, fontWeight: FontWeight.bold)),
              ]),
            ),
          ]);
        },
      ),
    ),
  );
}

class MainShell extends StatefulWidget {
  final bool dark;
  final ValueChanged<bool> onThemeChanged;
  const MainShell({super.key, required this.dark, required this.onThemeChanged});
  @override
  State<MainShell> createState() => _MainShellState();
}
class _MainShellState extends State<MainShell> {
  int tab = 0;
  final search = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(onOpenLibrary: () => setState(() => tab = 1), onSearch: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SearchPage()))),
      const LibraryPage(),
      MorePage(dark: widget.dark, onThemeChanged: widget.onThemeChanged),
    ];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('ميراث النبوة'), backgroundColor: Theme.of(context).colorScheme.surface),
        body: IndexedStack(index: tab, children: pages),
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (i) => setState(() => tab = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'ميراث النبوة'),
            NavigationDestination(icon: Icon(Icons.more_horiz), label: 'المزيد'),
          ],
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final VoidCallback onOpenLibrary;
  final VoidCallback onSearch;
  const HomePage({super.key, required this.onOpenLibrary, required this.onSearch});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    TextField(
      readOnly: true,
      onTap: onSearch,
      decoration: InputDecoration(hintText: 'ابحث عن كتاب أو قسم...', prefixIcon: const Icon(Icons.search), filled: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none)),
    ),
    const SizedBox(height: 22),
    FilledButton.icon(onPressed: onOpenLibrary, icon: const Icon(Icons.library_books), label: const Text('تصفح المكتبة')),
  ]);
}

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});
  @override
  State<SearchPage> createState() => _SearchPageState();
}
class _SearchPageState extends State<SearchPage> {
  String query = '';
  @override
  Widget build(BuildContext context) {
    final results = allBooks.where((b) => b.title.contains(query.trim())).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('البحث في المكتبة')),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: TextField(
            autofocus: true,
            onChanged: (v) => setState(() => query = v),
            decoration: InputDecoration(
              hintText: 'اكتب اسم الكتاب...',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: query.isEmpty ? null : IconButton(icon: const Icon(Icons.close), onPressed: () => setState(() => query = '')),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            ),
          ),
        ),
        Expanded(child: results.isEmpty
          ? const Center(child: Text('لا توجد نتائج مطابقة.'))
          : ListView.builder(
              itemCount: results.length,
              itemBuilder: (context, i) => ListTile(
                leading: const Icon(Icons.menu_book, color: burgundy),
                title: Text(results[i].title),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PdfReaderPage(book: results[i]))),
              ),
            )),
      ]),
    );
  }
}

String ar(int n) => n.toString().split('').map((d) => String.fromCharCode(0x0660 + int.parse(d))).join();

class Mark {
  final int page;
  final String name;
  final int t;
  const Mark(this.page, this.name, this.t);
  Map<String, dynamic> toJson() => {'p': page, 'n': name, 't': t};
  static Mark fromJson(Map<String, dynamic> j) => Mark(j['p'] as int, j['n'] as String, (j['t'] as int?) ?? 0);
}

String marksLabel(int n) {
  if (n == 1) return 'علامة واحدة';
  if (n == 2) return 'علامتان';
  if (n >= 3 && n <= 10) return '${ar(n)} علامات';
  return '${ar(n)} علامة';
}

class Bookmarks {
  static String _key(Book b) => 'bms_${b.asset}';
  static Future<List<Mark>> load(Book b) async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_key(b));
    if (raw != null) {
      try {
        final list = jsonDecode(raw) as List;
        return list.map((e) => Mark.fromJson(Map<String, dynamic>.from(e as Map))).toList();
      } catch (_) {
        return <Mark>[];
      }
    }
    final old = p.getInt('bm_${b.asset}');
    if (old != null) return [Mark(old, 'علامة', 0)];
    return <Mark>[];
  }
  static Future<void> save(Book b, List<Mark> marks) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_key(b), jsonEncode(marks.map((m) => m.toJson()).toList()));
  }
  static Future<Map<String, int>> counts(List<Book> books) async {
    final map = <String, int>{};
    for (final b in books) {
      final l = await load(b);
      if (l.isNotEmpty) map[b.asset] = l.length;
    }
    return map;
  }
}

class LibCategory {
  final String name;
  final IconData icon;
  final List<String> subs;
  const LibCategory(this.name, this.icon, this.subs);
}

const libCategories = <LibCategory>[
  LibCategory('العقيدة', Icons.mosque, ['المحتويات']),
  LibCategory('الفقه الشافعي', Icons.balance, ['المحتويات']),
  LibCategory('أصول الفقه', Icons.account_tree_outlined, ['المحتويات']),
  LibCategory('المنطق', Icons.psychology_outlined, ['المحتويات']),
  LibCategory('اللغة العربية', Icons.translate, ['النحو', 'العروض', 'البلاغة', 'الأدب']),
  LibCategory('علوم القرآن', Icons.auto_stories, []),
];

List<Book> booksFor(String category, String sub) {
  if (sub != 'المحتويات') return const <Book>[];
  if (category == 'العقيدة') return [...creedBooks, ...creedSharhBooks];
  if (category == 'الفقه الشافعي') return [...fiqhMatnBooks, ...fiqhSharhBooks];
  return const <Book>[];
}

class LibraryPage extends StatelessWidget {
  const LibraryPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
    children: [
      const Padding(
        padding: EdgeInsets.fromLTRB(4, 4, 4, 14),
        child: Text('أقسام المكتبة', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      ),
      GridView.count(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        crossAxisCount: 2,
        mainAxisSpacing: 14,
        crossAxisSpacing: 14,
        childAspectRatio: 1.05,
        children: libCategories.map((c) => _CategoryCard(c: c)).toList(),
      ),
    ],
  );
}

class _CategoryCard extends StatelessWidget {
  final LibCategory c;
  const _CategoryCard({required this.c});
  @override
  Widget build(BuildContext context) {
    final count = c.subs.fold<int>(0, (n, s) => n + booksFor(c.name, s).length);
    return Material(
      borderRadius: BorderRadius.circular(22),
      clipBehavior: Clip.antiAlias,
      elevation: 2,
      color: burgundy,
      child: InkWell(
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => c.subs.isEmpty ? EmptyCategoryPage(title: c.name) : SubCategoryPage(c: c))),
        child: Ink(
          decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [Color(0xFF8B344B), burgundy])),
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: const BoxDecoration(color: Color(0x2EE4B83F), shape: BoxShape.circle),
                child: Icon(c.icon, color: gold, size: 30),
              ),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(c.name, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text(count > 0 ? '${ar(count)} كتابًا' : 'قريبًا', style: const TextStyle(color: Colors.white70, fontSize: 13)),
              ]),
            ],
          ),
        ),
      ),
    );
  }
}

class SubCategoryPage extends StatelessWidget {
  final LibCategory c;
  const SubCategoryPage({super.key, required this.c});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(c.name)),
    body: ListView(
      padding: const EdgeInsets.all(16),
      children: c.subs.map((sub) {
        final n = booksFor(c.name, sub).length;
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          child: ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            leading: const CircleAvatar(backgroundColor: Color(0xFFFFF0C2), child: Icon(Icons.folder_open, color: burgundy)),
            title: Text(sub, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
            subtitle: Text(n > 0 ? '${ar(n)} كتابًا' : 'سيُضاف لاحقًا'),
            trailing: const Icon(Icons.chevron_left),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => n > 0 ? BookListPage(title: '${c.name} - $sub', books: booksFor(c.name, sub)) : EmptyCategoryPage(title: '${c.name} - $sub'))),
          ),
        );
      }).toList(),
    ),
  );
}

class EmptyCategoryPage extends StatelessWidget {
  final String title;
  const EmptyCategoryPage({super.key, required this.title});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(title)),
    body: const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(Icons.hourglass_empty, size: 48, color: burgundy),
      SizedBox(height: 12),
      Text('سيُضاف المحتوى إلى هذا القسم لاحقًا.'),
    ])),
  );
}

class BookListPage extends StatefulWidget {
  final String title;
  final List<Book> books;
  const BookListPage({super.key, required this.title, required this.books});
  @override
  State<BookListPage> createState() => _BookListPageState();
}
class _BookListPageState extends State<BookListPage> {
  Map<String, int> marks = {};
  @override
  void initState() {
    super.initState();
    _load();
  }
  Future<void> _load() async {
    final m = await Bookmarks.counts(widget.books);
    if (mounted) setState(() => marks = m);
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.title)),
    body: ListView.builder(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 24),
      itemCount: widget.books.length + 1,
      itemBuilder: (context, i) {
        if (i == 0) {
          return Container(
            margin: const EdgeInsets.only(bottom: 14),
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(gradient: const LinearGradient(colors: [burgundy, Color(0xFF8B344B)]), borderRadius: BorderRadius.circular(20)),
            child: Row(children: [
              const Icon(Icons.menu_book_rounded, color: gold, size: 36),
              const SizedBox(width: 14),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${ar(widget.books.length)} كتابًا', style: const TextStyle(color: gold, fontSize: 19, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text(marks.isEmpty ? 'اضغط على أي كتاب لبدء القراءة.' : 'لديك ${marksLabel(marks.values.fold<int>(0, (x, y) => x + y))} محفوظة.', style: const TextStyle(color: Colors.white, fontSize: 14)),
              ])),
            ]),
          );
        }
        final b = widget.books[i - 1];
        final mark = marks[b.asset];
        return Card(
          margin: const EdgeInsets.only(bottom: 10),
          clipBehavior: Clip.antiAlias,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          child: InkWell(
            onTap: () async {
              await Navigator.push(context, MaterialPageRoute(builder: (_) => PdfReaderPage(book: b)));
              _load();
            },
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(children: [
                Container(
                  width: 42,
                  height: 42,
                  alignment: Alignment.center,
                  decoration: const BoxDecoration(color: burgundy, shape: BoxShape.circle),
                  child: Text(ar(i), style: const TextStyle(color: gold, fontWeight: FontWeight.bold, fontSize: 16)),
                ),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(b.title, maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15.5, height: 1.45)),
                  const SizedBox(height: 6),
                  mark != null
                      ? Row(children: [
                          const Icon(Icons.bookmark, color: gold, size: 18),
                          const SizedBox(width: 4),
                          Text(marksLabel(mark), style: const TextStyle(color: burgundy, fontSize: 13, fontWeight: FontWeight.w600)),
                        ])
                      : const Row(children: [
                          Icon(Icons.picture_as_pdf_outlined, color: Colors.grey, size: 16),
                          SizedBox(width: 4),
                          Text('PDF', style: TextStyle(color: Colors.grey, fontSize: 12.5)),
                        ]),
                ])),
                const Icon(Icons.chevron_left),
              ]),
            ),
          ),
        );
      },
    ),
  );
}

class PdfReaderPage extends StatefulWidget {
  final Book book;
  const PdfReaderPage({super.key, required this.book});
  @override
  State<PdfReaderPage> createState() => _PdfReaderPageState();
}
class _PdfReaderPageState extends State<PdfReaderPage> {
  final controller = PdfViewerController();
  int page = 1;
  int total = 0;
  List<Mark> marks = [];

  void _snack(String text) {
    final m = ScaffoldMessenger.of(context);
    m.hideCurrentSnackBar();
    m.showSnackBar(SnackBar(content: Text(text), duration: const Duration(seconds: 2)));
  }

  Future<String?> _askName(String title, String initial) {
    final c = TextEditingController(text: initial);
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: TextField(controller: c, autofocus: true, maxLength: 60, decoration: const InputDecoration(hintText: 'اسم العلامة (اختياري)')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: const Text('حفظ')),
        ],
      ),
    );
  }

  Future<bool> _confirmDelete(Mark m) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف العلامة'),
        content: Text('هل تريدين حذف "${m.name}"؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حذف')),
        ],
      ),
    );
    return ok == true;
  }

  Future<void> _addMark() async {
    final p = page;
    final name = await _askName('علامة جديدة - صفحة ${ar(p)}', '');
    if (name == null) return;
    final m = Mark(p, name.isEmpty ? 'علامة صفحة ${ar(p)}' : name, DateTime.now().millisecondsSinceEpoch);
    final updated = [...marks, m];
    await Bookmarks.save(widget.book, updated);
    if (!mounted) return;
    setState(() => marks = updated);
    _snack('تم حفظ العلامة: ${m.name}');
  }

  void _showMarks() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setSheet) {
        final sorted = [...marks]..sort((a, b) => a.page.compareTo(b.page));
        return SafeArea(
          child: ConstrainedBox(
            constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.7),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                child: Row(children: [
                  Expanded(child: Text('العلامات (${ar(sorted.length)})', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
                  FilledButton.icon(
                    onPressed: () async {
                      Navigator.pop(ctx);
                      await _addMark();
                    },
                    icon: const Icon(Icons.bookmark_add_outlined),
                    label: const Text('علامة هنا'),
                  ),
                ]),
              ),
              const Divider(height: 1),
              if (sorted.isEmpty)
                const Padding(padding: EdgeInsets.all(28), child: Text('لا توجد علامات بعد.'))
              else
                Flexible(
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: sorted.length,
                    itemBuilder: (c, i) {
                      final m = sorted[i];
                      return ListTile(
                        leading: CircleAvatar(backgroundColor: burgundy, child: Text(ar(m.page), style: const TextStyle(color: gold, fontSize: 13, fontWeight: FontWeight.bold))),
                        title: Text(m.name),
                        subtitle: Text('صفحة ${ar(m.page)}'),
                        onTap: () {
                          Navigator.pop(ctx);
                          controller.goToPage(pageNumber: m.page);
                        },
                        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                          IconButton(
                            icon: const Icon(Icons.edit_outlined),
                            onPressed: () async {
                              final n = await _askName('تعديل اسم العلامة', m.name);
                              if (n == null) return;
                              final updated = marks.map((x) => identical(x, m) ? Mark(x.page, n.isEmpty ? x.name : n, x.t) : x).toList();
                              await Bookmarks.save(widget.book, updated);
                              if (!mounted) return;
                              setState(() => marks = updated);
                              setSheet(() {});
                            },
                          ),
                          IconButton(
                            icon: const Icon(Icons.delete_outline),
                            onPressed: () async {
                              if (!await _confirmDelete(m)) return;
                              final updated = marks.where((x) => !identical(x, m)).toList();
                              await Bookmarks.save(widget.book, updated);
                              if (!mounted) return;
                              setState(() => marks = updated);
                              setSheet(() {});
                            },
                          ),
                        ]),
                      );
                    },
                  ),
                ),
            ]),
          ),
        );
      }),
    );
  }

  Future<void> _goToDialog() async {
    final c = TextEditingController();
    final n = await showDialog<int>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('الانتقال إلى صفحة'),
        content: TextField(controller: c, keyboardType: TextInputType.number, autofocus: true, decoration: InputDecoration(hintText: '1 - $total')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, int.tryParse(c.text.trim())), child: const Text('انتقال')),
        ],
      ),
    );
    if (n != null && n >= 1 && n <= total) controller.goToPage(pageNumber: n);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      backgroundColor: burgundy,
      foregroundColor: Colors.white,
      title: Text(widget.book.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16)),
      actions: [
        IconButton(tooltip: 'إضافة علامة هنا', icon: const Icon(Icons.bookmark_add_outlined), onPressed: total == 0 ? null : _addMark),
        IconButton(
          tooltip: 'كل العلامات',
          icon: Icon(marks.isEmpty ? Icons.bookmarks_outlined : Icons.bookmarks, color: marks.isEmpty ? Colors.white : gold),
          onPressed: total == 0 ? null : _showMarks,
        ),
      ],
    ),
    body: Column(children: [
      Expanded(child: PdfViewer.asset(
        widget.book.asset,
        controller: controller,
        params: PdfViewerParams(
          backgroundColor: const Color(0xFFD9D4CC),
          interactionEndFrictionCoefficient: 0.008,
          viewerOverlayBuilder: (context, size, handleLinkTap) => [
            PdfViewerScrollThumb(
              controller: controller,
              orientation: ScrollbarOrientation.right,
              thumbSize: const Size(52, 36),
              thumbBuilder: (context, thumbSize, pageNumber, ctrl) => Container(
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: burgundy,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: gold, width: 1.5),
                  boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 4)],
                ),
                child: Text(pageNumber == null ? '' : ar(pageNumber), style: const TextStyle(color: gold, fontWeight: FontWeight.bold, fontSize: 14)),
              ),
            ),
          ],
          onPageChanged: (p) {
            if (p != null && mounted) setState(() => page = p);
          },
          onViewerReady: (document, ctrl) async {
            final list = await Bookmarks.load(widget.book);
            if (!mounted) return;
            final count = document.pages.length;
            setState(() {
              total = count;
              marks = list;
            });
            if (list.isNotEmpty) {
              final last = list.reduce((a, b) => a.t >= b.t ? a : b);
              if (last.page > 1 && last.page <= count) {
                ctrl.goToPage(pageNumber: last.page);
                _snack('تم الانتقال إلى آخر علامة: ${last.name}');
              }
            }
          },
        ),
      )),
      Container(
        color: burgundy,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        child: SafeArea(
          top: false,
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            IconButton(color: Colors.white, onPressed: page > 1 ? () => controller.goToPage(pageNumber: page - 1, duration: const Duration(milliseconds: 80)) : null, icon: const Icon(Icons.keyboard_arrow_up)),
            InkWell(
              onTap: total == 0 ? null : _goToDialog,
              borderRadius: BorderRadius.circular(10),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                child: Text(total == 0 ? '...' : '${ar(page)} / ${ar(total)}', style: const TextStyle(color: gold, fontWeight: FontWeight.bold, fontSize: 16)),
              ),
            ),
            IconButton(color: Colors.white, onPressed: total > 0 && page < total ? () => controller.goToPage(pageNumber: page + 1, duration: const Duration(milliseconds: 80)) : null, icon: const Icon(Icons.keyboard_arrow_down)),
          ]),
        ),
      ),
    ]),
  );
}

class MorePage extends StatelessWidget {
  final bool dark;
  final ValueChanged<bool> onThemeChanged;
  const MorePage({super.key, required this.dark, required this.onThemeChanged});
  @override
  Widget build(BuildContext context) => ListView(children: [
    SwitchListTile(
      secondary: const Icon(Icons.dark_mode_outlined),
      title: const Text('الوضع الداكن'),
      value: dark,
      onChanged: onThemeChanged,
    ),
    const ListTile(leading: Icon(Icons.info_outline), title: Text('عن التطبيق'), subtitle: Text('ميراث النبوة — مكتبة علمية للقراءة دون اتصال بالإنترنت.')),
    const ListTile(leading: Icon(Icons.library_books_outlined), title: Text('إصدار التطبيق'), subtitle: Text('1.0.0')),
  ]);
}
