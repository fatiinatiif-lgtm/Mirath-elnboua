import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:pdfrx/pdfrx.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const MirathApp());

const burgundy = Color(0xFF681B32);
const gold = Color(0xFFE4B83F);

class Book {
  final String title;
  final String asset;
  const Book(this.title, this.asset);
}

const creedBooks = <Book>[
  Book('منظومة عقيدة العوام للشيخ أحمد المرزوقي المكي', 'assets/books/01_aqidat_al_awam.pdf'),
  Book('منظومة جوهرة التوحيد للإمام برهان الدين إبراهيم اللقاني', 'assets/books/02_jawharat_al_tawhid.pdf'),
  Book('متن الخريدة البهية', 'assets/books/03_al_kharida_al_bahiyya.pdf'),
  Book('قصيدة بدء الأمالي للشيخ علي بن عثمان الأوشي', 'assets/books/04_bad_al_amali.pdf'),
  Book('منظومة إضاءة الدجنة في اعتقاد أهل السنة للعلامة أحمد المقري المغربي', 'assets/books/05_idaat_al_dujunna.pdf'),
  Book('متن قواعد العقائد للإمام أبي حامد الغزالي', 'assets/books/06_qawaid_al_aqaid.pdf'),
  Book('متن صغرى الصغرى للإمام أبي عبدالله محمد بن يوسف السنوسي', 'assets/books/07_sanusi_sughra_al_sughra.pdf'),
  Book('العقيدة الصغرى أم البراهين للإمام أبي عبدالله محمد بن يوسف السنوسي', 'assets/books/08_sanusi_umm_al_barahin.pdf'),
  Book('متن الحفيدة للإمام أبي عبدالله محمد بن يوسف السنوسي', 'assets/books/09_sanusi_hafida.pdf'),
  Book('متن المقدمات للإمام أبي عبدالله محمد بن يوسف السنوسي', 'assets/books/10_matn_al_muqaddimat.pdf'),
  Book('متن العقيدة الوسطى للإمام أبي عبدالله محمد بن يوسف السنوسي', 'assets/books/11_sanusi_wusta.pdf'),
  Book('العقيدة الكبرى للإمام أبي عبدالله محمد بن يوسف السنوسي', 'assets/books/12_sanusi_kubra.pdf'),
  Book('العقيدة الطحاوية للإمام أحمد بن محمد الطحاوي', 'assets/books/13_al_tahawiyya.pdf'),
  Book('متن العقيدة النسفية للإمام عمر بن محمد النسفي', 'assets/books/14_al_nasafiyya.pdf'),
  Book('متن العقيدة التوحيدية للعلامة أبي البركات أحمد بن أحمد الدردير', 'assets/books/15_al_tawhidiyya_dardir.pdf'),
  Book('عقيدة أهل الإسلام للإمام عبدالله بن علوي الحداد', 'assets/books/16_aqidat_ahl_al_islam.pdf'),
  Book('كفاية العوام فيما يجب عليهم من علم الكلام للشيخ محمد الفضالي الشافعي', 'assets/books/17_kifayat_al_awam.pdf'),
  Book('الاقتصاد في الاعتقاد لحجة الإسلام محمد بن محمد الغزالي', 'assets/books/18_al_iqtisad_fil_itiqad.pdf'),
  Book('متن العقائد العضدية للإمام عضد الدين عبدالرحمن بن أحمد الإيجي', 'assets/books/19_al_adudiyya.pdf'),
  Book('دروس التوحيد للعلامة محمد بن أحمد الشاطري', 'assets/books/20_duroos_tawhid_shatiri.pdf'),
  Book('متن دروس التوحيد للعلامة محمد بن سالم بن حفيظ', 'assets/books/21_matn_duroos_tawhid_hafiz.pdf'),
  Book('رسالة في علم التوحيد للعلامة إبراهيم بن محمد الباجوري', 'assets/books/22_risala_ilm_tawhid_bajuri.pdf'),
  Book('عقيدة السلطان محمد الفاتح جواهر العقائد للعلامة المولى خضر بك بن', 'assets/books/23_aqidat_al_fatih.pdf'),
];

const creedSharhBooks = <Book>[
  Book('الروضة الندية شرح العقيدة الطحاوية', 'assets/books/aqeeda_s_01_al_rawda_al_nadiyya_sharh_al_tahawiyya.pdf'),
];

const fiqhMatnBooks = <Book>[
  Book('مختصر أبي شجاع المسمى متن الغاية والتقريب أو غاية الاختصار', 'assets/books/fiqh_m_01_mukhtasar_abi_shuja_ghayat_al_ikhtisar.pdf'),
  Book('متن سفينة النجاة', 'assets/books/fiqh_m_02_matn_safinat_al_naja.pdf'),
  Book('المقدمة الحضرمية', 'assets/books/fiqh_m_03_al_muqaddima_al_hadramiyya.pdf'),
  Book('اللباب في الفقه الشّافعي', 'assets/books/fiqh_m_04_al_lubab_fil_fiqh_al_shafii.pdf'),
  Book('متن صفوة نظم الزبد', 'assets/books/fiqh_m_05_matn_safwat_nazm_al_zubad.pdf'),
  Book('الشافي الأنيس في نظم ياقوت النفيس', 'assets/books/fiqh_m_06_al_shafi_al_anis_nazm_yaqut_al_nafis.pdf'),
  Book('منظومة تحفة الشافعية', 'assets/books/fiqh_m_07_manzumat_tuhfat_al_shafiiyya.pdf'),
  Book('نهاية التدريب نظم غاية التقريب النسخة المعتمدة', 'assets/books/fiqh_m_08_nihayat_al_tadrib_nazm_ghayat_al_taqrib.pdf'),
  Book('نهاية التدريب في نظم غاية التقريب', 'assets/books/fiqh_m_09_nihayat_al_tadrib_fi_nazm_ghayat_al_taqrib.pdf'),
  Book('التّيسير نظم التّحرير', 'assets/books/fiqh_m_10_al_taysir_nazm_al_tahrir.pdf'),
];

const fiqhSharhBooks = <Book>[
  Book('فتح القريب المجيب', 'assets/books/fiqh_s_01_fath_al_qarib_al_mujib.pdf'),
  Book('شرح متن الغاية والتقريب', 'assets/books/fiqh_s_02_sharh_matn_al_ghaya_wal_taqrib.pdf'),
  Book('النهاية في شرح الغاية', 'assets/books/fiqh_s_03_al_nihaya_fi_sharh_al_ghaya.pdf'),
  Book('الت ذهيب في أدلة متن الغاية', 'assets/books/fiqh_s_04_al_tadhhib_fi_adillat_matn_al_ghaya.pdf'),
  Book('تشجير متن الغاية والتقريب', 'assets/books/fiqh_s_05_tashjir_matn_al_ghaya_wal_taqrib.pdf'),
  Book('المعتمد عند الشافعية', 'assets/books/fiqh_s_06_al_mutamad_inda_al_shafiiyya.pdf'),
  Book('المفطرات المعاصرة عند الشافعية', 'assets/books/fiqh_s_07_al_mufattirat_al_muasira.pdf'),
  Book('الإقناع', 'assets/books/fiqh_s_08_al_iqna.pdf'),
  Book('المفرد لألفاظ الزبد', 'assets/books/fiqh_s_09_al_mufrad_li_alfaz_al_zubad.pdf'),
  Book('فتح الصمد شرح الزبد لابن زياد الوضاحي تحقيق العامري', 'assets/books/fiqh_s_10_fath_al_samad_sharh_al_zubad.pdf'),
  Book('مواهب الصمد في حل الفاظ الزبد لأحمد بن حجازي الفشني طبعة مكتبة دار', 'assets/books/fiqh_s_11_mawahib_al_samad_fi_hall_alfaz_al_zubad.pdf'),
  Book('فتح القدير الخبير بشرح تيسير التحرير', 'assets/books/fiqh_s_12_fath_al_qadir_al_khabir.pdf'),
  Book('تحرير تنقيح اللباب', 'assets/books/fiqh_s_13_tahrir_tanqih_al_lubab.pdf'),
];

const fiqhMoreBooks = <Book>[
  Book('الإقناع المجلد الأول', 'assets/books/fiqh_x_01_al_iqna_vol1.pdf'),
  Book('الإقناع المجلد الثّاني', 'assets/books/fiqh_x_02_al_iqna_vol2.pdf'),
  Book('منهاج الطالبين الحداد (١)', 'assets/books/fiqh_x_03_minhaj_al_talibin_alhaddad_1.pdf'),
  Book('منهاج الطالبين الحداد (٢)', 'assets/books/fiqh_x_04_minhaj_al_talibin_alhaddad_2.pdf'),
  Book('منهاج الطالبين الحداد (٣)', 'assets/books/fiqh_x_05_minhaj_al_talibin_alhaddad_3.pdf'),
  Book('تعليقات على المنهاج', 'assets/books/fiqh_x_06_taliqat_ala_al_minhaj.pdf'),
  Book('تهذيب تحفة الحبيب في شرح نهاية التدريب', 'assets/books/fiqh_x_07_tahdhib_tuhfat_al_habib_nihayat_al_tadrib.pdf'),
  Book('منار الهدى شرح سفينة النجا', 'assets/books/fiqh_x_08_manar_al_huda_sharh_safinat_al_naja.pdf'),
  Book('مجمل الفقه', 'assets/books/fiqh_x_09_mujmal_al_fiqh.pdf'),
  Book('عقود الدرر', 'assets/books/fiqh_x_10_uqud_al_durar.pdf'),
  Book('الفوائد الثمينة', 'assets/books/fiqh_x_11_al_fawaid_al_thamina.pdf'),
  Book('الأهم في فقه طالب العلم', 'assets/books/fiqh_x_12_al_ahamm_fi_fiqh_talib_al_ilm.pdf'),
  Book('التذكرة لابن الملقن', 'assets/books/fiqh_x_13_al_tadhkira_ibn_al_mulaqqin.pdf'),
  Book('الملخص المفيد', 'assets/books/fiqh_x_14_al_mulakhkhas_al_mufid.pdf'),
  Book('اجتماع العيدين', 'assets/books/fiqh_x_15_ijtimaa_al_idayn.pdf'),
  Book('لمعة الفقه', 'assets/books/fiqh_x_16_lumat_al_fiqh.pdf'),
  Book('ألفية الحبشي', 'assets/books/fiqh_x_17_alfiyyat_al_habashi.pdf'),
  Book('الدروس الفقهية', 'assets/books/fiqh_x_18_al_duroos_al_fiqhiyya.pdf'),
  Book('مسألتان في التيمم', 'assets/books/fiqh_x_19_masalatan_fi_al_tayammum.pdf'),
  Book('المهارات الفقهية', 'assets/books/fiqh_x_20_al_maharat_al_fiqhiyya.pdf'),
  Book('مناسبة أبواب الفقه', 'assets/books/fiqh_x_21_munasabat_abwab_al_fiqh.pdf'),
  Book('سموط الدرر في نظم تحفة ابن حجر', 'assets/books/fiqh_y_01_sumut_al_durar_nazm_tuhfat_ibn_hajar.pdf'),
  Book('الوجيز في الفقه الشافعي كامل ١،٢ الغزالي', 'assets/books/fiqh_y_02_al_wajiz_fil_fiqh_al_shafii_al_ghazali.pdf'),
  Book('خلاصة الكلام في ما يختص بالمرأة من الأحكام على مذهب الشافعية الكرام', 'assets/books/fiqh_y_03_khulasat_al_kalam_fima_yakhtass_bil_mara.pdf'),
  Book('المناسك الصغرى', 'assets/books/fiqh_y_04_al_manasik_al_sughra.pdf'),
  Book('الإيضاح في المناسك', 'assets/books/fiqh_y_05_al_idah_fil_manasik.pdf'),
  Book('الغرر البهية', 'assets/books/fiqh_y_06_al_ghurar_al_bahiyya.pdf'),
  Book('إعانة الناسك', 'assets/books/fiqh_y_07_ianat_al_nasik.pdf'),
  Book('إزاحة الستارة', 'assets/books/fiqh_y_08_izahat_al_sitara.pdf'),
  Book('منهج الطلاب - زكريا الأنصاري', 'assets/books/fiqh_y_09_manhaj_al_tullab_zakariyya_al_ansari.pdf'),
  Book('الياقوت النفيس ط المنهاج', 'assets/books/fiqh_y_10_al_yaqut_al_nafis_dar_al_minhaj.pdf'),
];

const usulBooks = <Book>[
  Book('تحفة الطالب بنظم أصول ابن الحاجب', 'assets/books/usul_01_tuhfat_al_talib_nazm_usul_ibn_al_hajib.pdf'),
  Book('المدخل إلى أصول الفقه - السقاف', 'assets/books/usul_02_al_madkhal_usul_fiqh_saqqaf.pdf'),
  Book('تقريب أصول الورقات', 'assets/books/usul_03_taqrib_usul_al_waraqat.pdf'),
  Book('الخلاصة في أصول الفقه', 'assets/books/usul_04_al_khulasa_fi_usul_al_fiqh.pdf'),
  Book('تشجير اللمع في أصول الفقه', 'assets/books/usul_05_tashjir_al_luma.pdf'),
  Book('تشجيرات نيل الرجاء', 'assets/books/usul_06_tashjirat_nayl_al_raja.pdf'),
  Book('شرح منظومة الورقات في أصول الفقه', 'assets/books/usul_07_sharh_manzumat_al_waraqat.pdf'),
  Book('مطالع المسرات على نظم الورقات', 'assets/books/usul_08_matali_al_musarrat.pdf'),
  Book('موجز العبارات على نظم الورقات', 'assets/books/usul_09_mujaz_al_ibarat.pdf'),
  Book('أصول الفقه الميسر', 'assets/books/usul_10_usul_al_fiqh_al_muyassar.pdf'),
  Book('مجموع رسائل في أصول الفقه للإمام السيوطي', 'assets/books/usul_11_majmu_rasail_usul_suyuti.pdf'),
  Book('البرهان في أصول الفقه', 'assets/books/usul_12_al_burhan_fi_usul_al_fiqh.pdf'),
  Book('اللمع في أصول الفقه', 'assets/books/usul_13_al_luma_fi_usul_al_fiqh.pdf'),
  Book('سلم الوصول لكل من يرقى الى الاصول', 'assets/books/usul_14_sullam_al_wusul.pdf'),
];



final allBooks = <Book>[...creedBooks, ...creedSharhBooks, ...fiqhMatnBooks, ...fiqhSharhBooks, ...fiqhMoreBooks, ...usulBooks];

class MirathApp extends StatefulWidget {
  const MirathApp({super.key});
  @override
  State<MirathApp> createState() => _MirathAppState();
}

class _MirathAppState extends State<MirathApp> {
  bool dark = false;
  bool started = false;
  @override
  Widget build(BuildContext context) {
    final scheme = ColorScheme.fromSeed(
      seedColor: burgundy,
      brightness: dark ? Brightness.dark : Brightness.light,
      primary: burgundy,
      secondary: gold,
    );
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child!),
      title: 'ميراث النبوة',
      theme: ThemeData(colorScheme: scheme, useMaterial3: true, scaffoldBackgroundColor: dark ? const Color(0xFF171417) : const Color(0xFFFFFCF3), appBarTheme: const AppBarTheme(centerTitle: true)),
      home: started ? MainShell(dark: dark, onThemeChanged: (v) => setState(() => dark = v)) : SplashScreen(onDone: () => setState(() => started = true)),
    );
  }
}

const kDeco = 'ArefRuqaa';
const goldFaint = Color(0x1AE4B83F);
const goldLine = Color(0x66E4B83F);

bool isDarkCtx(BuildContext c) => Theme.of(c).brightness == Brightness.dark;

String booksLabel(int n) {
  if (n == 1) return 'كتاب واحد';
  if (n == 2) return 'كتابان';
  if (n >= 3 && n <= 10) return '${ar(n)} كتب';
  return '${ar(n)} كتابًا';
}

class PatternPainter extends CustomPainter {
  final Color color;
  final double cell;
  const PatternPainter(this.color, {this.cell = 48});
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.9;
    for (double y = 0; y <= size.height + cell; y += cell) {
      for (double x = 0; x <= size.width + cell; x += cell) {
        _star(canvas, Offset(x, y), cell * 0.40, paint);
        _star(canvas, Offset(x + cell / 2, y + cell / 2), cell * 0.17, paint);
      }
    }
  }
  void _star(Canvas canvas, Offset o, double r, Paint p) {
    for (final a in const [0.0, math.pi / 4]) {
      final path = Path();
      for (int i = 0; i < 4; i++) {
        final ang = a + i * math.pi / 2;
        final pt = Offset(o.dx + r * math.cos(ang), o.dy + r * math.sin(ang));
        if (i == 0) {
          path.moveTo(pt.dx, pt.dy);
        } else {
          path.lineTo(pt.dx, pt.dy);
        }
      }
      path.close();
      canvas.drawPath(path, p);
    }
  }
  @override
  bool shouldRepaint(covariant PatternPainter old) => old.color != color || old.cell != cell;
}

class FramePainter extends CustomPainter {
  final Color color;
  const FramePainter(this.color);
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4;
    final outer = RRect.fromRectAndRadius(Rect.fromLTWH(18, 18, size.width - 36, size.height - 36), const Radius.circular(22));
    final inner = RRect.fromRectAndRadius(Rect.fromLTWH(27, 27, size.width - 54, size.height - 54), const Radius.circular(16));
    canvas.drawRRect(outer, p);
    p.strokeWidth = 0.8;
    canvas.drawRRect(inner, p);
    final fill = Paint()..color = color;
    final spots = [
      Offset(18, 18),
      Offset(size.width - 18, 18),
      Offset(18, size.height - 18),
      Offset(size.width - 18, size.height - 18),
      Offset(size.width / 2, 18),
      Offset(size.width / 2, size.height - 18),
    ];
    for (final o in spots) {
      final d = Path()
        ..moveTo(o.dx, o.dy - 7)
        ..lineTo(o.dx + 7, o.dy)
        ..lineTo(o.dx, o.dy + 7)
        ..lineTo(o.dx - 7, o.dy)
        ..close();
      canvas.drawPath(d, fill);
    }
  }
  @override
  bool shouldRepaint(covariant FramePainter old) => old.color != color;
}

class OrnamentDivider extends StatelessWidget {
  final Color color;
  final double width;
  const OrnamentDivider({super.key, this.color = gold, this.width = 220});
  @override
  Widget build(BuildContext context) => SizedBox(
    width: width,
    height: 16,
    child: Row(children: [
      Expanded(child: Container(height: 1, decoration: BoxDecoration(gradient: LinearGradient(colors: [color, Colors.transparent])))),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: Transform.rotate(angle: math.pi / 4, child: Container(width: 8, height: 8, color: color)),
      ),
      Expanded(child: Container(height: 1, decoration: BoxDecoration(gradient: LinearGradient(colors: [Colors.transparent, color])))),
    ]),
  );
}

class StarBadge extends StatelessWidget {
  final String text;
  final double size;
  const StarBadge(this.text, {super.key, this.size = 48});
  @override
  Widget build(BuildContext context) => SizedBox(
    width: size,
    height: size,
    child: CustomPaint(
      painter: _StarPainter(),
      child: Center(child: Text(text, style: TextStyle(color: gold, fontWeight: FontWeight.bold, fontSize: size * 0.30))),
    ),
  );
}

class _StarPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2;
    final path = Path();
    for (int i = 0; i < 16; i++) {
      final rad = i.isEven ? r : r * 0.80;
      final ang = -math.pi / 2 + i * math.pi / 8;
      final pt = Offset(c.dx + rad * math.cos(ang), c.dy + rad * math.sin(ang));
      if (i == 0) {
        path.moveTo(pt.dx, pt.dy);
      } else {
        path.lineTo(pt.dx, pt.dy);
      }
    }
    path.close();
    canvas.drawPath(path, Paint()..color = burgundy);
    canvas.drawPath(
      path,
      Paint()
        ..color = gold
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.6,
    );
  }
  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

class SplashScreen extends StatefulWidget {
  final VoidCallback onDone;
  const SplashScreen({super.key, required this.onDone});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}
class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late final AnimationController c;
  @override
  void initState() {
    super.initState();
    c = AnimationController(vsync: this, duration: const Duration(seconds: 5));
    c.addStatusListener((st) {
      if (st == AnimationStatus.completed && mounted) widget.onDone();
    });
    c.forward();
  }
  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }
  double _iv(double t, double a, double b) => ((t - a) / (b - a)).clamp(0.0, 1.0).toDouble();
  Widget _goldText(String text, double size) => ShaderMask(
    blendMode: BlendMode.srcIn,
    shaderCallback: (r) => const LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [Color(0xFFFFF1B8), gold, Color(0xFFB8860B)],
    ).createShader(r),
    child: FittedBox(
      fit: BoxFit.scaleDown,
      child: Text(text, textAlign: TextAlign.center, style: TextStyle(fontFamily: kDeco, fontWeight: FontWeight.w700, color: Colors.white, fontSize: size, height: 1.55)),
    ),
  );
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: burgundy,
    body: AnimatedBuilder(
      animation: c,
      builder: (context, _) {
        final t = c.value;
        final a1 = Curves.easeOut.transform(_iv(t, 0.06, 0.36));
        final a2 = Curves.easeOut.transform(_iv(t, 0.28, 0.58));
        final a3 = Curves.easeOut.transform(_iv(t, 0.52, 0.82));
        return Stack(children: [
          Positioned.fill(
            child: DecoratedBox(
              decoration: const BoxDecoration(
                gradient: RadialGradient(radius: 1.0, colors: [Color(0xFF8B2A45), Color(0xFF5A1429), Color(0xFF3E0C1C)]),
              ),
            ),
          ),
          Positioned.fill(child: CustomPaint(painter: const PatternPainter(goldFaint))),
          Positioned.fill(child: Opacity(opacity: a1, child: const CustomPaint(painter: FramePainter(goldLine)))),
          SafeArea(
            child: Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 44),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Opacity(opacity: a1, child: const OrnamentDivider()),
                  const SizedBox(height: 26),
                  Opacity(
                    opacity: a1,
                    child: Transform.scale(scale: 0.9 + 0.1 * a1, child: _goldText('بِسْمِ اللَّهِ', 68)),
                  ),
                  Opacity(
                    opacity: a2,
                    child: Transform.scale(scale: 0.9 + 0.1 * a2, child: _goldText('الرَّحْمَٰنِ الرَّحِيمِ', 52)),
                  ),
                  const SizedBox(height: 26),
                  Opacity(opacity: a3, child: const OrnamentDivider()),
                ]),
              ),
            ),
          ),
          Positioned(
            left: 70,
            right: 70,
            bottom: 52,
            child: LinearProgressIndicator(value: t, minHeight: 2, color: gold, backgroundColor: Colors.white12),
          ),
        ]);
      },
    ),
  );
}

class MainShell extends StatefulWidget {
  final bool dark;
  final ValueChanged<bool> onThemeChanged;
  const MainShell({super.key, required this.dark, required this.onThemeChanged});
  @override
  State<MainShell> createState() => _MainShellState();
}
class _MainShellState extends State<MainShell> {
  int tab = 0;
  final search = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(onOpenLibrary: () => setState(() => tab = 1), onSearch: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SearchPage()))),
      const LibraryPage(),
      MorePage(dark: widget.dark, onThemeChanged: widget.onThemeChanged),
    ];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('ميراث النبوة'), backgroundColor: Theme.of(context).colorScheme.surface),
        body: IndexedStack(index: tab, children: pages),
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (i) => setState(() => tab = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'ميراث النبوة'),
            NavigationDestination(icon: Icon(Icons.more_horiz), label: 'المزيد'),
          ],
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final VoidCallback onOpenLibrary;
  final VoidCallback onSearch;
  const HomePage({super.key, required this.onOpenLibrary, required this.onSearch});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    TextField(
      readOnly: true,
      onTap: onSearch,
      decoration: InputDecoration(hintText: 'ابحث عن كتاب أو قسم...', prefixIcon: const Icon(Icons.search), filled: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none)),
    ),
    const SizedBox(height: 22),
    FilledButton.icon(onPressed: onOpenLibrary, icon: const Icon(Icons.library_books), label: const Text('تصفح المكتبة')),
  ]);
}

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});
  @override
  State<SearchPage> createState() => _SearchPageState();
}
class _SearchPageState extends State<SearchPage> {
  String query = '';
  @override
  Widget build(BuildContext context) {
    final results = allBooks.where((b) => b.title.contains(query.trim())).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('البحث في المكتبة')),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: TextField(
            autofocus: true,
            onChanged: (v) => setState(() => query = v),
            decoration: InputDecoration(
              hintText: 'اكتب اسم الكتاب...',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: query.isEmpty ? null : IconButton(icon: const Icon(Icons.close), onPressed: () => setState(() => query = '')),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            ),
          ),
        ),
        Expanded(child: results.isEmpty
          ? const Center(child: Text('لا توجد نتائج مطابقة.'))
          : ListView.builder(
              itemCount: results.length,
              itemBuilder: (context, i) => ListTile(
                leading: const Icon(Icons.menu_book, color: burgundy),
                title: Text(results[i].title),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PdfReaderPage(book: results[i]))),
              ),
            )),
      ]),
    );
  }
}

String ar(int n) => n.toString().split('').map((d) => String.fromCharCode(0x0660 + int.parse(d))).join();

class Mark {
  final int page;
  final String name;
  final int t;
  const Mark(this.page, this.name, this.t);
  Map<String, dynamic> toJson() => {'p': page, 'n': name, 't': t};
  static Mark fromJson(Map<String, dynamic> j) => Mark(j['p'] as int, j['n'] as String, (j['t'] as int?) ?? 0);
}

String marksLabel(int n) {
  if (n == 1) return 'علامة واحدة';
  if (n == 2) return 'علامتان';
  if (n >= 3 && n <= 10) return '${ar(n)} علامات';
  return '${ar(n)} علامة';
}

class Bookmarks {
  static String _key(Book b) => 'bms_${b.asset}';
  static Future<List<Mark>> load(Book b) async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_key(b));
    if (raw != null) {
      try {
        final list = jsonDecode(raw) as List;
        return list.map((e) => Mark.fromJson(Map<String, dynamic>.from(e as Map))).toList();
      } catch (_) {
        return <Mark>[];
      }
    }
    final old = p.getInt('bm_${b.asset}');
    if (old != null) return [Mark(old, 'علامة', 0)];
    return <Mark>[];
  }
  static Future<void> save(Book b, List<Mark> marks) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_key(b), jsonEncode(marks.map((m) => m.toJson()).toList()));
  }
  static Future<Map<String, int>> counts(List<Book> books) async {
    final map = <String, int>{};
    for (final b in books) {
      final l = await load(b);
      if (l.isNotEmpty) map[b.asset] = l.length;
    }
    return map;
  }
}

class IndexItem {
  final String title;
  final int page;
  const IndexItem(this.title, this.page);
  Map<String, dynamic> toJson() => {'t': title, 'p': page};
  static IndexItem fromJson(Map<String, dynamic> j) => IndexItem(j['t'] as String, j['p'] as int);
}

int? parsePage(String s) {
  final t = s.trim().replaceAllMapped(RegExp('[٠-٩]'), (x) => (x[0]!.codeUnitAt(0) - 0x0660).toString());
  return int.tryParse(t);
}

class BookIndex {
  static String _k(Book b) => 'idx_${b.asset}';
  static String _ko(Book b) => 'idxoff_${b.asset}';
  static Future<List<IndexItem>> load(Book b) async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_k(b));
    if (raw == null) return <IndexItem>[];
    try {
      final list = jsonDecode(raw) as List;
      return list.map((e) => IndexItem.fromJson(Map<String, dynamic>.from(e as Map))).toList();
    } catch (_) {
      return <IndexItem>[];
    }
  }
  static Future<void> save(Book b, List<IndexItem> items) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_k(b), jsonEncode(items.map((i) => i.toJson()).toList()));
  }
  static Future<int> loadOffset(Book b) async {
    final p = await SharedPreferences.getInstance();
    return p.getInt(_ko(b)) ?? 0;
  }
  static Future<void> saveOffset(Book b, int o) async {
    final p = await SharedPreferences.getInstance();
    await p.setInt(_ko(b), o);
  }
}

class LibCategory {
  final String name;
  final IconData icon;
  const LibCategory(this.name, this.icon);
}

const libCategories = <LibCategory>[
  LibCategory('العقيدة', Icons.mosque),
  LibCategory('الفقه الشافعي', Icons.balance),
  LibCategory('أصول الفقه', Icons.account_tree_outlined),
];

List<Book> booksFor(String category) {
  if (category == 'العقيدة') return [...creedBooks, ...creedSharhBooks];
  if (category == 'الفقه الشافعي') return [...fiqhMatnBooks, ...fiqhSharhBooks, ...fiqhMoreBooks];
  if (category == 'أصول الفقه') return usulBooks;
  return const <Book>[];
}

class LibraryPage extends StatelessWidget {
  const LibraryPage({super.key});
  @override
  Widget build(BuildContext context) {
    final accent = isDarkCtx(context) ? gold : burgundy;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 28),
      children: [
        const SizedBox(height: 6),
        Center(child: Text('أقسام المكتبة', style: TextStyle(fontFamily: kDeco, fontWeight: FontWeight.w700, fontSize: 32, color: accent, height: 1.4))),
        const SizedBox(height: 2),
        const Center(child: OrnamentDivider(width: 200)),
        const SizedBox(height: 20),
        ...libCategories.map((c) => _CategoryCard(c: c)),
      ],
    );
  }
}

class _CategoryCard extends StatelessWidget {
  final LibCategory c;
  const _CategoryCard({required this.c});
  String get subtitle {
    if (c.name == 'العقيدة') return 'متون وشروح علم التوحيد';
    if (c.name == 'الفقه الشافعي') return 'متون وشروح ومناسك';
    return 'متون وشروح أصول الفقه';
  }
  @override
  Widget build(BuildContext context) {
    final count = booksFor(c.name).length;
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Material(
        borderRadius: BorderRadius.circular(26),
        clipBehavior: Clip.antiAlias,
        elevation: 4,
        shadowColor: Colors.black54,
        color: burgundy,
        child: InkWell(
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BookListPage(title: c.name, books: booksFor(c.name)))),
          child: Ink(
            height: 150,
            decoration: const BoxDecoration(
              gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [Color(0xFF9A3A55), burgundy, Color(0xFF4A1020)]),
            ),
            child: Stack(children: [
              Positioned.fill(child: CustomPaint(painter: const PatternPainter(goldFaint))),
              Positioned(left: -26, bottom: -30, child: Icon(c.icon, size: 150, color: const Color(0x14E4B83F))),
              Padding(
                padding: const EdgeInsets.all(18),
                child: Row(children: [
                  Container(
                    width: 74,
                    height: 74,
                    decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0x26E4B83F), border: Border.all(color: gold, width: 1.6)),
                    child: Icon(c.icon, color: gold, size: 36),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(c.name, style: const TextStyle(fontFamily: kDeco, fontWeight: FontWeight.w700, color: gold, fontSize: 30, height: 1.3)),
                      const SizedBox(height: 2),
                      Text(subtitle, style: const TextStyle(color: Colors.white70, fontSize: 13.5)),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(color: const Color(0x33000000), borderRadius: BorderRadius.circular(20), border: Border.all(color: goldLine)),
                        child: Text(booksLabel(count), style: const TextStyle(color: Colors.white, fontSize: 12.5, fontWeight: FontWeight.w600)),
                      ),
                    ]),
                  ),
                  const Icon(Icons.chevron_left, color: gold, size: 30),
                ]),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}

class BookListPage extends StatefulWidget {
  final String title;
  final List<Book> books;
  const BookListPage({super.key, required this.title, required this.books});
  @override
  State<BookListPage> createState() => _BookListPageState();
}
class _BookListPageState extends State<BookListPage> {
  Map<String, int> marks = {};
  String q = '';
  final ctl = TextEditingController();
  @override
  void initState() {
    super.initState();
    _load();
  }
  @override
  void dispose() {
    ctl.dispose();
    super.dispose();
  }
  Future<void> _load() async {
    final m = await Bookmarks.counts(widget.books);
    if (mounted) setState(() => marks = m);
  }
  Widget _chip(IconData icon, String label, Color fg, Color bg) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
    decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(12)),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 14, color: fg),
      const SizedBox(width: 4),
      Text(label, style: TextStyle(color: fg, fontSize: 12, fontWeight: FontWeight.w600)),
    ]),
  );
  @override
  Widget build(BuildContext context) {
    final dark = isDarkCtx(context);
    final accent = dark ? gold : burgundy;
    final all = widget.books;
    final key = q.trim();
    final shown = <int>[for (int i = 0; i < all.length; i++) if (key.isEmpty || all[i].title.contains(key)) i];
    final totalMarks = marks.values.fold<int>(0, (x, y) => x + y);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: burgundy,
        foregroundColor: gold,
        title: Text(widget.title, style: const TextStyle(fontFamily: kDeco, fontWeight: FontWeight.w700, fontSize: 24)),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 28),
        itemCount: shown.isEmpty ? 3 : shown.length + 2,
        itemBuilder: (context, i) {
          if (i == 0) {
            return Container(
              margin: const EdgeInsets.only(bottom: 14),
              clipBehavior: Clip.antiAlias,
              decoration: BoxDecoration(
                gradient: const LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [Color(0xFF9A3A55), burgundy, Color(0xFF4A1020)]),
                borderRadius: BorderRadius.circular(24),
                boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 10, offset: Offset(0, 4))],
              ),
              child: Stack(children: [
                Positioned.fill(child: CustomPaint(painter: const PatternPainter(goldFaint))),
                Padding(
                  padding: const EdgeInsets.all(18),
                  child: Row(children: [
                    Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0x26E4B83F), border: Border.all(color: gold, width: 1.5)),
                      child: const Icon(Icons.auto_stories, color: gold, size: 30),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(booksLabel(all.length), style: const TextStyle(fontFamily: kDeco, fontWeight: FontWeight.w700, color: gold, fontSize: 26, height: 1.3)),
                        const SizedBox(height: 2),
                        Text(totalMarks == 0 ? 'اضغطي على أي كتاب لبدء القراءة.' : 'لديكِ ${marksLabel(totalMarks)} محفوظة.', style: const TextStyle(color: Colors.white, fontSize: 13.5)),
                      ]),
                    ),
                  ]),
                ),
              ]),
            );
          }
          if (i == 1) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 14),
              child: TextField(
                controller: ctl,
                onChanged: (v) => setState(() => q = v),
                decoration: InputDecoration(
                  hintText: 'ابحثي في هذا القسم...',
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: q.isEmpty
                      ? null
                      : IconButton(
                          icon: const Icon(Icons.close),
                          onPressed: () {
                            ctl.clear();
                            setState(() => q = '');
                          },
                        ),
                  filled: true,
                  fillColor: dark ? const Color(0xFF241F24) : Colors.white,
                  contentPadding: const EdgeInsets.symmetric(vertical: 0),
                  enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: goldLine)),
                  focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide(color: accent, width: 1.6)),
                ),
              ),
            );
          }
          if (shown.isEmpty) {
            return const Padding(padding: EdgeInsets.all(30), child: Center(child: Text('لا توجد كتب مطابقة.')));
          }
          final idx = shown[i - 2];
          final b = all[idx];
          final mark = marks[b.asset];
          return Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Material(
              color: dark ? const Color(0xFF241F24) : Colors.white,
              elevation: 2,
              shadowColor: Colors.black38,
              borderRadius: BorderRadius.circular(20),
              clipBehavior: Clip.antiAlias,
              child: InkWell(
                onTap: () async {
                  await Navigator.push(context, MaterialPageRoute(builder: (_) => PdfReaderPage(book: b)));
                  _load();
                },
                child: Container(
                  decoration: const BoxDecoration(border: Border(right: BorderSide(color: gold, width: 4))),
                  padding: const EdgeInsets.all(14),
                  child: Row(children: [
                    StarBadge(ar(idx + 1)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(b.title, maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15.5, height: 1.5)),
                        const SizedBox(height: 8),
                        mark != null
                            ? _chip(Icons.bookmark, marksLabel(mark), burgundy, const Color(0xFFFFE9A8))
                            : _chip(Icons.picture_as_pdf_outlined, 'PDF', Colors.grey.shade600, dark ? const Color(0x22FFFFFF) : const Color(0xFFF1EDE4)),
                      ]),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      width: 34,
                      height: 34,
                      decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: goldLine, width: 1.4)),
                      child: Icon(Icons.chevron_left, color: accent),
                    ),
                  ]),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class PdfReaderPage extends StatefulWidget {
  final Book book;
  const PdfReaderPage({super.key, required this.book});
  @override
  State<PdfReaderPage> createState() => _PdfReaderPageState();
}
class _PdfReaderPageState extends State<PdfReaderPage> {
  final controller = PdfViewerController();
  int page = 1;
  int total = 0;
  List<Mark> marks = [];
  List<IndexItem> index = [];
  int offset = 0;

  void _snack(String text) {
    final m = ScaffoldMessenger.of(context);
    m.hideCurrentSnackBar();
    m.showSnackBar(SnackBar(content: Text(text), duration: const Duration(seconds: 2)));
  }

  Future<String?> _askName(String title, String initial) {
    final c = TextEditingController(text: initial);
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: TextField(controller: c, autofocus: true, maxLength: 60, decoration: const InputDecoration(hintText: 'اسم العلامة (اختياري)')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: const Text('حفظ')),
        ],
      ),
    );
  }

  Future<bool> _confirmDelete(Mark m) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف العلامة'),
        content: Text('هل تريدين حذف "${m.name}"؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حذف')),
        ],
      ),
    );
    return ok == true;
  }

  Future<void> _addMark() async {
    final p = page;
    final name = await _askName('علامة جديدة - صفحة ${ar(p)}', '');
    if (name == null) return;
    final m = Mark(p, name.isEmpty ? 'علامة صفحة ${ar(p)}' : name, DateTime.now().millisecondsSinceEpoch);
    final updated = [...marks, m];
    await Bookmarks.save(widget.book, updated);
    if (!mounted) return;
    setState(() => marks = updated);
    _snack('تم حفظ العلامة: ${m.name}');
  }

  void _showMarks() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setSheet) {
        final sorted = [...marks]..sort((a, b) => a.page.compareTo(b.page));
        return SafeArea(
          child: ConstrainedBox(
            constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.7),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                child: Row(children: [
                  Expanded(child: Text('العلامات (${ar(sorted.length)})', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
                  FilledButton.icon(
                    onPressed: () async {
                      Navigator.pop(ctx);
                      await _addMark();
                    },
                    icon: const Icon(Icons.bookmark_add_outlined),
                    label: const Text('علامة هنا'),
                  ),
                ]),
              ),
              const Divider(height: 1),
              if (sorted.isEmpty)
                const Padding(padding: EdgeInsets.all(28), child: Text('لا توجد علامات بعد.'))
              else
                Flexible(
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: sorted.length,
                    itemBuilder: (c, i) {
                      final m = sorted[i];
                      return ListTile(
                        leading: CircleAvatar(backgroundColor: burgundy, child: Text(ar(m.page), style: const TextStyle(color: gold, fontSize: 13, fontWeight: FontWeight.bold))),
                        title: Text(m.name),
                        subtitle: Text('صفحة ${ar(m.page)}'),
                        onTap: () {
                          Navigator.pop(ctx);
                          controller.goToPage(pageNumber: m.page);
                        },
                        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                          IconButton(
                            icon: const Icon(Icons.edit_outlined),
                            onPressed: () async {
                              final n = await _askName('تعديل اسم العلامة', m.name);
                              if (n == null) return;
                              final updated = marks.map((x) => identical(x, m) ? Mark(x.page, n.isEmpty ? x.name : n, x.t) : x).toList();
                              await Bookmarks.save(widget.book, updated);
                              if (!mounted) return;
                              setState(() => marks = updated);
                              setSheet(() {});
                            },
                          ),
                          IconButton(
                            icon: const Icon(Icons.delete_outline),
                            onPressed: () async {
                              if (!await _confirmDelete(m)) return;
                              final updated = marks.where((x) => !identical(x, m)).toList();
                              await Bookmarks.save(widget.book, updated);
                              if (!mounted) return;
                              setState(() => marks = updated);
                              setSheet(() {});
                            },
                          ),
                        ]),
                      );
                    },
                  ),
                ),
            ]),
          ),
        );
      }),
    );
  }

  void _goPrinted(int printed) {
    if (total == 0) return;
    final target = (printed + offset).clamp(1, total).toInt();
    controller.goToPage(pageNumber: target);
  }

  Future<IndexItem?> _itemDialog(String heading, {IndexItem? initial}) {
    final t = TextEditingController(text: initial?.title ?? '');
    final pg = TextEditingController(text: initial != null ? initial.page.toString() : (page - offset < 1 ? 1 : page - offset).toString());
    return showDialog<IndexItem>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(heading),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: t, autofocus: true, maxLength: 100, decoration: const InputDecoration(labelText: 'العنوان (باب / فصل / مسألة)')),
          TextField(controller: pg, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'رقم الصفحة في الكتاب')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(
            onPressed: () {
              final n = parsePage(pg.text);
              final title = t.text.trim();
              if (title.isEmpty || n == null || n < 1) return;
              Navigator.pop(ctx, IndexItem(title, n));
            },
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
  }

  Future<bool> _confirmText(String text) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تأكيد الحذف'),
        content: Text(text),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حذف')),
        ],
      ),
    );
    return ok == true;
  }

  Future<void> _bulkAdd() async {
    final c = TextEditingController();
    final text = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('إضافة عدة عناوين'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('اكتبي كل عنوان في سطر، ورقم صفحته في آخر السطر. مثال:\nكتاب الطهارة 5\nباب الصلاة 23\nباب الزكاة 41', style: TextStyle(fontSize: 13)),
            const SizedBox(height: 10),
            TextField(controller: c, autofocus: true, minLines: 6, maxLines: 10, decoration: const InputDecoration(border: OutlineInputBorder())),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text), child: const Text('إضافة')),
        ],
      ),
    );
    if (text == null) return;
    final re = RegExp(r'^(.*?)[\s\-–—:.…،,]*([0-9٠-٩]+)\s*$');
    final added = <IndexItem>[];
    for (final line in text.split('\n')) {
      final mt = re.firstMatch(line.trim());
      if (mt == null) continue;
      final title = mt.group(1)!.trim();
      final n = parsePage(mt.group(2)!);
      if (title.isEmpty || n == null || n < 1) continue;
      added.add(IndexItem(title, n));
    }
    if (added.isEmpty) {
      _snack('لم أجد أسطرًا بالشكل المطلوب (عنوان ثم رقم).');
      return;
    }
    final updated = [...index, ...added];
    await BookIndex.save(widget.book, updated);
    if (!mounted) return;
    setState(() => index = updated);
    _snack('تمت إضافة ${ar(added.length)} عنوانًا إلى الفهرس');
  }

  Future<void> _setOffset() async {
    final c = TextEditingController(text: (offset + 1).toString());
    final n = await showDialog<int>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('ضبط الترقيم'),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('أحيانًا يختلف رقم الصفحة المطبوع في الكتاب عن رقم صفحة الـ PDF. اكتبي رقم صفحة الـ PDF التي تحمل الرقم ١ في الكتاب (مثلًا ٧ إذا بدأ ترقيم الكتاب بعد ست صفحات).', style: TextStyle(fontSize: 13)),
          const SizedBox(height: 10),
          TextField(controller: c, keyboardType: TextInputType.number, autofocus: true),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, parsePage(c.text)), child: const Text('حفظ')),
        ],
      ),
    );
    if (n == null || n < 1 || (total > 0 && n > total)) return;
    await BookIndex.saveOffset(widget.book, n - 1);
    if (!mounted) return;
    setState(() => offset = n - 1);
    _snack('تم ضبط الترقيم');
  }

  void _showIndex() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setSheet) {
        final sorted = [...index]..sort((a, b) => a.page.compareTo(b.page));
        return SafeArea(
          child: ConstrainedBox(
            constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.78),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 8, 4),
                child: Row(children: [
                  Expanded(child: Text('الفهرس (${ar(sorted.length)})', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
                  IconButton(
                    tooltip: 'ضبط الترقيم',
                    icon: const Icon(Icons.tune),
                    onPressed: () async {
                      await _setOffset();
                      setSheet(() {});
                    },
                  ),
                  IconButton(
                    tooltip: 'إضافة عدة عناوين',
                    icon: const Icon(Icons.playlist_add),
                    onPressed: () async {
                      await _bulkAdd();
                      setSheet(() {});
                    },
                  ),
                  FilledButton.icon(
                    onPressed: () async {
                      final it = await _itemDialog('عنوان جديد');
                      if (it == null) return;
                      final updated = [...index, it];
                      await BookIndex.save(widget.book, updated);
                      if (!mounted) return;
                      setState(() => index = updated);
                      setSheet(() {});
                    },
                    icon: const Icon(Icons.add),
                    label: const Text('عنوان'),
                  ),
                ]),
              ),
              const Divider(height: 1),
              if (sorted.isEmpty)
                const Padding(padding: EdgeInsets.all(28), child: Text('لا يوجد فهرس لهذا الكتاب بعد. أضيفي عناوين الأبواب مع أرقام صفحاتها، ثم اضغطي على أي عنوان للانتقال إليه.', textAlign: TextAlign.center))
              else
                Flexible(
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: sorted.length,
                    itemBuilder: (c, i) {
                      final it = sorted[i];
                      return ListTile(
                        leading: CircleAvatar(backgroundColor: burgundy, child: Text(ar(it.page), style: const TextStyle(color: gold, fontSize: 12, fontWeight: FontWeight.bold))),
                        title: Text(it.title),
                        onTap: () {
                          Navigator.pop(ctx);
                          _goPrinted(it.page);
                        },
                        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                          IconButton(
                            icon: const Icon(Icons.edit_outlined),
                            onPressed: () async {
                              final n = await _itemDialog('تعديل العنوان', initial: it);
                              if (n == null) return;
                              final updated = index.map((x) => identical(x, it) ? n : x).toList();
                              await BookIndex.save(widget.book, updated);
                              if (!mounted) return;
                              setState(() => index = updated);
                              setSheet(() {});
                            },
                          ),
                          IconButton(
                            icon: const Icon(Icons.delete_outline),
                            onPressed: () async {
                              if (!await _confirmText('هل تريدين حذف \"${it.title}\" من الفهرس؟')) return;
                              final updated = index.where((x) => !identical(x, it)).toList();
                              await BookIndex.save(widget.book, updated);
                              if (!mounted) return;
                              setState(() => index = updated);
                              setSheet(() {});
                            },
                          ),
                        ]),
                      );
                    },
                  ),
                ),
            ]),
          ),
        );
      }),
    );
  }

  Future<void> _goToDialog() async {
    final c = TextEditingController();
    final n = await showDialog<int>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('الانتقال إلى صفحة'),
        content: TextField(controller: c, keyboardType: TextInputType.number, autofocus: true, decoration: InputDecoration(hintText: '1 - $total')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, int.tryParse(c.text.trim())), child: const Text('انتقال')),
        ],
      ),
    );
    if (n != null && n >= 1 && n <= total) controller.goToPage(pageNumber: n);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      backgroundColor: burgundy,
      foregroundColor: Colors.white,
      title: Text(widget.book.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16)),
      actions: [
        IconButton(
          tooltip: 'الفهرس',
          icon: Icon(Icons.format_list_numbered, color: index.isEmpty ? Colors.white : gold),
          onPressed: total == 0 ? null : _showIndex,
        ),
        IconButton(tooltip: 'إضافة علامة هنا', icon: const Icon(Icons.bookmark_add_outlined), onPressed: total == 0 ? null : _addMark),
        IconButton(
          tooltip: 'كل العلامات',
          icon: Icon(marks.isEmpty ? Icons.bookmarks_outlined : Icons.bookmarks, color: marks.isEmpty ? Colors.white : gold),
          onPressed: total == 0 ? null : _showMarks,
        ),
      ],
    ),
    body: Column(children: [
      Expanded(child: PdfViewer.asset(
        widget.book.asset,
        controller: controller,
        params: PdfViewerParams(
          backgroundColor: const Color(0xFFD9D4CC),
          interactionEndFrictionCoefficient: 0.008,
          layoutPages: (pages, params) {
            final widths = pages.map((x) => x.width).toList()..sort();
            final w = widths[widths.length ~/ 2];
            final rects = <Rect>[];
            var y = params.margin;
            for (final pg in pages) {
              final h = pg.width <= 0 ? pg.height : pg.height * w / pg.width;
              rects.add(Rect.fromLTWH(params.margin, y, w, h));
              y += h + params.margin;
            }
            return PdfPageLayout(pageLayouts: rects, documentSize: Size(w + params.margin * 2, y));
          },
          viewerOverlayBuilder: (context, size, handleLinkTap) => [
            PdfViewerScrollThumb(
              controller: controller,
              orientation: ScrollbarOrientation.right,
              thumbSize: const Size(52, 36),
              thumbBuilder: (context, thumbSize, pageNumber, ctrl) => Container(
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: burgundy,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: gold, width: 1.5),
                  boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 4)],
                ),
                child: Text(pageNumber == null ? '' : ar(pageNumber), style: const TextStyle(color: gold, fontWeight: FontWeight.bold, fontSize: 14)),
              ),
            ),
          ],
          onPageChanged: (p) {
            if (p != null && mounted) setState(() => page = p);
          },
          onViewerReady: (document, ctrl) async {
            final list = await Bookmarks.load(widget.book);
            final idx = await BookIndex.load(widget.book);
            final off = await BookIndex.loadOffset(widget.book);
            if (!mounted) return;
            final count = document.pages.length;
            setState(() {
              total = count;
              marks = list;
              index = idx;
              offset = off;
            });
            if (list.isNotEmpty) {
              final last = list.reduce((a, b) => a.t >= b.t ? a : b);
              if (last.page > 1 && last.page <= count) {
                ctrl.goToPage(pageNumber: last.page);
                _snack('تم الانتقال إلى آخر علامة: ${last.name}');
              }
            }
          },
        ),
      )),
      Container(
        color: burgundy,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        child: SafeArea(
          top: false,
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            IconButton(color: Colors.white, onPressed: page > 1 ? () => controller.goToPage(pageNumber: page - 1, duration: const Duration(milliseconds: 80)) : null, icon: const Icon(Icons.keyboard_arrow_up)),
            InkWell(
              onTap: total == 0 ? null : _goToDialog,
              borderRadius: BorderRadius.circular(10),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                child: Text(total == 0 ? '...' : '${ar(page)} / ${ar(total)}', style: const TextStyle(color: gold, fontWeight: FontWeight.bold, fontSize: 16)),
              ),
            ),
            IconButton(color: Colors.white, onPressed: total > 0 && page < total ? () => controller.goToPage(pageNumber: page + 1, duration: const Duration(milliseconds: 80)) : null, icon: const Icon(Icons.keyboard_arrow_down)),
          ]),
        ),
      ),
    ]),
  );
}

class MorePage extends StatelessWidget {
  final bool dark;
  final ValueChanged<bool> onThemeChanged;
  const MorePage({super.key, required this.dark, required this.onThemeChanged});
  @override
  Widget build(BuildContext context) => ListView(children: [
    SwitchListTile(
      secondary: const Icon(Icons.dark_mode_outlined),
      title: const Text('الوضع الداكن'),
      value: dark,
      onChanged: onThemeChanged,
    ),
    const ListTile(leading: Icon(Icons.info_outline), title: Text('عن التطبيق'), subtitle: Text('ميراث النبوة — مكتبة علمية للقراءة دون اتصال بالإنترنت.')),
    const ListTile(leading: Icon(Icons.library_books_outlined), title: Text('إصدار التطبيق'), subtitle: Text('1.0.0')),
  ]);
}
